export interface Stock {
  ticker: string;
  name: string;
  sector: string;
  price: number;
  change: number;
  changePercent: number;
  beta: number;
  volatility: number;
}

export interface PortfolioItem {
  id: string;
  ticker: string;
  shares: number;
  purchasePrice: number;
  purchaseDate: string;
}

export interface StockHistoryItem {
  date: string;
  price: number;
}

export type MarketHistory = Record<string, StockHistoryItem[]>;

export interface AlertNotification {
  id: string;
  timestamp: string;
  ticker: string;
  type: "PRICE_ABOVE" | "PRICE_BELOW" | "RECOMMENDATION" | "RISK_ALERT";
  message: string;
  status: "SENT" | "PENDING";
}

export interface AlertRule {
  id: string;
  ticker: string;
  type: "ABOVE" | "BELOW";
  threshold: number;
  email: string;
}
