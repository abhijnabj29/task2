import { PortfolioItem, Stock } from "../types";
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, BarChart, Bar, XAxis, YAxis } from "recharts";
import { Shield, AlertTriangle, HelpCircle, Activity } from "lucide-react";

interface RiskDashboardProps {
  portfolio: PortfolioItem[];
  liveStocks: Record<string, Stock>;
}

export default function RiskDashboard({ portfolio, liveStocks }: RiskDashboardProps) {
  // Compute portfolio allocation details
  const getSectorAllocation = () => {
    const allocations: Record<string, number> = {};
    let totalVal = 0;

    portfolio.forEach((item) => {
      const stock = liveStocks[item.ticker];
      const price = stock ? stock.price : item.purchasePrice;
      const val = item.shares * price;
      const sector = stock ? stock.sector : "Technology";

      allocations[sector] = (allocations[sector] || 0) + val;
      totalVal += val;
    });

    if (totalVal === 0) return [];

    return Object.keys(allocations).map((sec) => ({
      name: sec,
      value: allocations[sec],
      percentage: parseFloat(((allocations[sec] / totalVal) * 100).toFixed(1))
    }));
  };

  const getAssetWeights = () => {
    const weights: Record<string, number> = {};
    let totalVal = 0;

    portfolio.forEach((item) => {
      const stock = liveStocks[item.ticker];
      const price = stock ? stock.price : item.purchasePrice;
      const val = item.shares * price;

      weights[item.ticker] = (weights[item.ticker] || 0) + val;
      totalVal += val;
    });

    if (totalVal === 0) return [];

    return Object.keys(weights).map((sym) => ({
      name: sym,
      value: weights[sym],
      percentage: parseFloat(((weights[sym] / totalVal) * 100).toFixed(1))
    }));
  };

  const calculateCompositeBeta = () => {
    let totalVal = 0;
    let weightedBetaSum = 0;

    portfolio.forEach((item) => {
      const stock = liveStocks[item.ticker];
      const price = stock ? stock.price : item.purchasePrice;
      const val = item.shares * price;
      const beta = stock ? stock.beta : 1.0;

      weightedBetaSum += val * beta;
      totalVal += val;
    });

    if (totalVal === 0) return 0;
    return parseFloat((weightedBetaSum / totalVal).toFixed(2));
  };

  const sectorData = getSectorAllocation();
  const assetWeights = getAssetWeights();
  const beta = calculateCompositeBeta();

  // Colors palette for Recharts
  const COLORS = ["#6366F1", "#10B981", "#F59E0B", "#EF4444", "#8B5CF6", "#EC4899", "#06B6D4"];

  const getBetaDescription = (b: number) => {
    if (b === 0) return { title: "N/A", text: "Add stock holdings to calculate overall exposure.", color: "text-slate-400" };
    if (b < 0.9) return { title: "Defensive (Low Beta)", text: "Less volatile than the S&P 500. Insulates during correction phases.", color: "text-emerald-400" };
    if (b <= 1.2) return { title: "Market Aligned", text: "Fluctuates similarly to the broad indices. Normal risk profile.", color: "text-indigo-400" };
    return { title: "High Growth / Alpha (Aggressive Beta)", text: "Highly sensitive to broader market swings. Excellent during rallies, high drawdown risks.", color: "text-amber-400" };
  };

  const betaDesc = getBetaDescription(beta);

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
      {/* Portfolio Risk Overview */}
      <div className="lg:col-span-4 space-y-6">
        {/* Beta Card */}
        <div className="bg-[#16181C] rounded-2xl border border-slate-800 p-6 shadow-lg">
          <div className="flex items-center justify-between mb-4">
            <h4 className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
              Composite Beta Coefficient
            </h4>
            <Shield className="w-5 h-5 text-indigo-400" />
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-4xl font-bold text-white">{beta || "N/A"}</span>
            {beta > 0 && <span className="text-xs text-slate-500 font-mono">Market Base: 1.0</span>}
          </div>
          <div className="mt-4">
            <span className={`text-xs font-semibold ${betaDesc.color}`}>
              {betaDesc.title}
            </span>
            <p className="text-slate-400 text-xs mt-1 leading-relaxed">
              {betaDesc.text}
            </p>
          </div>
        </div>

        {/* VAR Estimate Card */}
        <div className="bg-[#16181C] rounded-2xl border border-slate-800 p-6 shadow-lg">
          <div className="flex items-center justify-between mb-4">
            <h4 className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
              Drawdown Projection (95% VaR)
            </h4>
            <AlertTriangle className="w-5 h-5 text-amber-400" />
          </div>
          <div className="flex items-baseline gap-1">
            <span className="text-3xl font-bold text-white">
              {beta === 0 ? "N/A" : `-${(beta * 10.4).toFixed(1)}%`}
            </span>
          </div>
          <p className="text-slate-400 text-xs mt-3 leading-relaxed">
            Historical 30-day downside forecast at a 95% confidence ceiling based on composite sector volatility indices.
          </p>
        </div>
      </div>

      {/* Diversification Visuals */}
      <div className="lg:col-span-8 grid grid-cols-1 md:grid-cols-2 gap-6 bg-[#16181C] rounded-2xl border border-slate-800 p-6 shadow-lg">
        {/* Sector Diversification Pie */}
        <div>
          <h4 className="text-sm font-semibold text-white mb-4 flex items-center gap-1.5">
            <Activity className="w-4 h-4 text-indigo-400" />
            Sector Weightings Allocation
          </h4>
          
          {sectorData.length === 0 ? (
            <div className="h-[220px] flex items-center justify-center border border-dashed border-slate-800 rounded-xl text-slate-500 text-xs">
              No holdings logged.
            </div>
          ) : (
            <div className="h-[220px] relative">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={sectorData}
                    cx="50%"
                    cy="50%"
                    innerRadius={55}
                    outerRadius={80}
                    paddingAngle={3}
                    dataKey="value"
                  >
                    {sectorData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip formatter={(value: number) => `$${value.toLocaleString()}`} />
                </PieChart>
              </ResponsiveContainer>
              
              {/* Floating Legends */}
              <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 text-center pointer-events-none">
                <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wider block">Sectors</span>
                <span className="text-lg font-bold text-white block">{sectorData.length}</span>
              </div>
            </div>
          )}
          
          <div className="mt-4 grid grid-cols-2 gap-2">
            {sectorData.map((entry, index) => (
              <div key={entry.name} className="flex items-center gap-1.5 text-xs">
                <span className="w-2.5 h-2.5 rounded-full shrink-0" style={{ backgroundColor: COLORS[index % COLORS.length] }}></span>
                <span className="text-slate-300 truncate">{entry.name}</span>
                <span className="text-slate-500 font-mono">({entry.percentage}%)</span>
              </div>
            ))}
          </div>
        </div>

        {/* Weights Bar chart */}
        <div>
          <h4 className="text-sm font-semibold text-white mb-4 flex items-center gap-1.5">
            <HelpCircle className="w-4 h-4 text-emerald-400" />
            Individual Asset Weights
          </h4>

          {assetWeights.length === 0 ? (
            <div className="h-[220px] flex items-center justify-center border border-dashed border-slate-800 rounded-xl text-slate-500 text-xs">
              No positions.
            </div>
          ) : (
            <div className="h-[220px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={assetWeights} margin={{ left: -10, right: 10, top: 10, bottom: 0 }}>
                  <XAxis dataKey="name" stroke="#475569" fontSize={10} tickLine={false} />
                  <YAxis stroke="#475569" fontSize={10} tickLine={false} />
                  <Tooltip formatter={(value: number) => `$${value.toLocaleString()}`} />
                  <Bar dataKey="value" fill="#6366F1" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          )}

          <div className="mt-4 space-y-1 overflow-y-auto max-h-[80px]">
            {assetWeights.slice(0, 4).map((asset) => (
              <div key={asset.name} className="flex justify-between text-xs text-slate-400">
                <span>{asset.name}</span>
                <span className="font-semibold text-white">{asset.percentage}%</span>
              </div>
            ))}
            {assetWeights.length > 4 && (
              <div className="text-[10px] text-slate-500 italic text-right">
                + {assetWeights.length - 4} other holdings
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
