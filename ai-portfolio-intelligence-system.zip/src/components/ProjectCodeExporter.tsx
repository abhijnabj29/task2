import { useState } from "react";
import { PYTHON_PROJECT_FILES } from "../pythonProjectData";
import { Download, FileCode, Check, Copy, Settings, Server, Database, ChevronRight, HelpCircle } from "lucide-react";

export default function ProjectCodeExporter() {
  const [activeFile, setActiveFile] = useState<keyof typeof PYTHON_PROJECT_FILES>("app.py");
  const [copied, setCopied] = useState(false);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(PYTHON_PROJECT_FILES[activeFile]);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error("Failed to copy text: ", err);
    }
  };

  const handleDownload = (filename: string, content: string) => {
    const blob = new Blob([content], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <div id="project-exporter-root" className="grid grid-cols-1 lg:grid-cols-12 gap-8">
      {/* Visual Diagrams Section */}
      <div id="visual-diagrams-card" className="lg:col-span-12 bg-[#16181C] rounded-2xl border border-slate-800 p-6 shadow-lg">
        <h3 id="diagrams-heading" className="text-xl font-semibold text-white mb-2 flex items-center gap-2">
          <Settings className="w-5 h-5 text-indigo-400" />
          System Architecture & Operational Flow
        </h3>
        <p id="diagrams-sub" className="text-slate-400 text-sm mb-6">
          The structural layout of the Streamlit application powered by a MySQL schema, yfinance API, scikit-learn forecasts, and server-side Gemini intelligence.
        </p>

        <div id="diagrams-grid" className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Architecture Chart */}
          <div id="architecture-diagram" className="border border-slate-800 rounded-xl p-4 bg-slate-900/40 flex flex-col justify-between">
            <h4 id="arch-title" className="text-sm font-semibold text-white mb-4 flex items-center gap-2">
              <Server className="w-4 h-4 text-emerald-400" />
              System Infrastructure Map
            </h4>
            <div id="arch-svg-container" className="flex items-center justify-center p-4 min-h-[220px]">
              <svg className="w-full max-w-[420px]" viewBox="0 0 420 220" fill="none" xmlns="http://www.w3.org/2000/svg">
                {/* User node */}
                <rect x="10" y="85" width="80" height="50" rx="8" fill="#1E293B" stroke="#475569" strokeWidth="2" />
                <text x="50" y="110" dominantBaseline="middle" textAnchor="middle" fontSize="11" fontWeight="600" fill="#E2E8F0">User Client</text>
                <text x="50" y="124" dominantBaseline="middle" textAnchor="middle" fontSize="9" fill="#94A3B8">Web Browser</text>

                {/* Arrow to UI */}
                <path d="M 90 110 L 122 110" stroke="#475569" strokeWidth="2" strokeDasharray="3 3" markerEnd="url(#arrow)" />

                {/* UI node */}
                <rect x="130" y="15" width="110" height="190" rx="10" fill="#1E1B4B" fillOpacity="0.2" stroke="#4F46E5" strokeWidth="2" />
                <text x="185" y="40" dominantBaseline="middle" textAnchor="middle" fontSize="12" fontWeight="700" fill="#818CF8">Streamlit App</text>
                
                {/* Inner microservice layers */}
                <rect x="140" y="65" width="90" height="30" rx="4" fill="#111418" stroke="#4F46E5" strokeWidth="1" />
                <text x="185" y="80" dominantBaseline="middle" textAnchor="middle" fontSize="10" fontWeight="600" fill="#818CF8">UI Terminal</text>

                <rect x="140" y="110" width="90" height="30" rx="4" fill="#111418" stroke="#4F46E5" strokeWidth="1" />
                <text x="185" y="125" dominantBaseline="middle" textAnchor="middle" fontSize="10" fontWeight="600" fill="#818CF8">ML / Regressions</text>

                <rect x="140" y="155" width="90" height="30" rx="4" fill="#111418" stroke="#4F46E5" strokeWidth="1" />
                <text x="185" y="170" dominantBaseline="middle" textAnchor="middle" fontSize="10" fontWeight="600" fill="#818CF8">Data Exporters</text>

                {/* Arrow to backend / external APIs */}
                <path d="M 240 75 L 290 55" stroke="#4F46E5" strokeWidth="1.5" markerEnd="url(#arrow)" />
                <path d="M 240 125 L 290 125" stroke="#4F46E5" strokeWidth="1.5" markerEnd="url(#arrow)" />
                <path d="M 240 170 L 290 185" stroke="#4F46E5" strokeWidth="1.5" markerEnd="url(#arrow)" />

                {/* External Tickers Service */}
                <rect x="300" y="30" width="110" height="40" rx="6" fill="#022C22" fillOpacity="0.3" stroke="#059669" strokeWidth="1.5" />
                <text x="355" y="45" dominantBaseline="middle" textAnchor="middle" fontSize="10" fontWeight="700" fill="#34D399">yfinance API</text>
                <text x="355" y="58" dominantBaseline="middle" textAnchor="middle" fontSize="8" fill="#10B981">Real-time quotes</text>

                {/* DB Manager */}
                <rect x="300" y="105" width="110" height="40" rx="6" fill="#451A03" fillOpacity="0.3" stroke="#D97706" strokeWidth="1.5" />
                <text x="355" y="120" dominantBaseline="middle" textAnchor="middle" fontSize="10" fontWeight="700" fill="#FBBF24">MySQL Server</text>
                <text x="355" y="133" dominantBaseline="middle" textAnchor="middle" fontSize="8" fill="#F59E0B">Auth & Portfolios</text>

                {/* Gemini AI API */}
                <rect x="300" y="165" width="110" height="40" rx="6" fill="#3B0764" fillOpacity="0.3" stroke="#9333EA" strokeWidth="1.5" />
                <text x="355" y="180" dominantBaseline="middle" textAnchor="middle" fontSize="10" fontWeight="700" fill="#C084FC">Gemini 1.5 LLM</text>
                <text x="355" y="193" dominantBaseline="middle" textAnchor="middle" fontSize="8" fill="#A855F7">Strategic advice</text>

                {/* Markers definition */}
                <defs>
                  <marker id="arrow" viewBox="0 0 10 10" refX="6" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
                    <path d="M 0 1 L 10 5 L 0 9 z" fill="#475569" />
                  </marker>
                </defs>
              </svg>
            </div>
            <div id="arch-caption" className="text-[11px] text-slate-500 mt-2 text-center">
              The layout operates with state caching to prevent Yahoo Finance API rate limits.
            </div>
          </div>

          {/* Core App Logic Flowchart */}
          <div id="logic-flowchart" className="border border-slate-800 rounded-xl p-4 bg-slate-900/40 flex flex-col justify-between">
            <h4 id="flowchart-title" className="text-sm font-semibold text-white mb-4 flex items-center gap-2">
              <Database className="w-4 h-4 text-indigo-400" />
              MySQL Portfolio Schema Map
            </h4>
            <div id="flowchart-content" className="space-y-3 py-1">
              {/* User table info */}
              <div className="bg-[#111418] p-3 rounded-lg border border-slate-800 shadow-sm flex items-start gap-3">
                <div className="w-5 h-5 rounded bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 flex items-center justify-center font-bold text-xs">U</div>
                <div className="flex-1 text-xs">
                  <div className="font-semibold text-white">users</div>
                  <div className="text-slate-500 font-mono text-[10px]">id (PK) | username | email | risk_profile | investment_goal</div>
                </div>
              </div>
              {/* Arrow */}
              <div className="flex justify-center my-1">
                <ChevronRight className="w-4 h-4 text-slate-500 transform rotate-90" />
              </div>
              {/* Portfolio table info */}
              <div className="bg-[#111418] p-3 rounded-lg border border-slate-800 shadow-sm flex items-start gap-3">
                <div className="w-5 h-5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 flex items-center justify-center font-bold text-xs">P</div>
                <div className="flex-1 text-xs">
                  <div className="font-semibold text-white">portfolios <span className="text-[10px] text-indigo-400 font-normal">(FK to users)</span></div>
                  <div className="text-slate-500 font-mono text-[10px]">id (PK) | user_id (FK) | ticker | shares | purchase_price | purchase_date</div>
                </div>
              </div>
              {/* Arrow split */}
              <div className="flex justify-around my-1">
                <ChevronRight className="w-4 h-4 text-slate-500 transform rotate-90" />
                <ChevronRight className="w-4 h-4 text-slate-500 transform rotate-90" />
              </div>
              {/* Double targets: transactions and alert_rules */}
              <div className="grid grid-cols-2 gap-3">
                <div className="bg-[#111418] p-2 rounded-lg border border-slate-800 shadow-sm text-xs">
                  <div className="font-semibold text-white flex items-center gap-1">
                    <span className="w-3 h-3 rounded bg-amber-500/10 text-amber-400 border border-amber-500/20 flex items-center justify-center font-bold text-[8px]">T</span>
                    transactions
                  </div>
                  <div className="text-slate-500 font-mono text-[9px] mt-1">id | user_id | ticker | action_type | shares | price</div>
                </div>
                <div className="bg-[#111418] p-2 rounded-lg border border-slate-800 shadow-sm text-xs">
                  <div className="font-semibold text-white flex items-center gap-1">
                    <span className="w-3 h-3 rounded bg-purple-500/10 text-purple-400 border border-purple-500/20 flex items-center justify-center font-bold text-[8px]">A</span>
                    alert_rules
                  </div>
                  <div className="text-slate-500 font-mono text-[9px] mt-1">id | user_id | ticker | alert_type | threshold</div>
                </div>
              </div>
            </div>
            <div id="logic-caption" className="text-[11px] text-slate-500 text-center mt-2">
              Referential cascade guarantees automatic deletion of all portfolios when user accounts are closed.
            </div>
          </div>
        </div>
      </div>

      {/* Code Viewer Section */}
      <div id="code-viewer-card" className="lg:col-span-12 bg-[#16181C] rounded-2xl border border-slate-800 shadow-lg flex flex-col h-[650px] overflow-hidden">
        {/* Header toolbar */}
        <div id="viewer-header" className="bg-slate-900 px-6 py-4 flex flex-wrap items-center justify-between gap-4 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <FileCode className="w-5 h-5 text-indigo-400" />
            <h3 id="viewer-title" className="font-medium text-slate-200">
              Python + MySQL Workspace Explorer
            </h3>
          </div>

          <div className="flex items-center gap-2">
            <button
              id="btn-copy-code"
              onClick={handleCopy}
              className="px-3 py-1.5 rounded-lg text-xs font-medium text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 transition flex items-center gap-1"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              {copied ? "Copied" : "Copy Content"}
            </button>
            <button
              id="btn-download-file"
              onClick={() => handleDownload(activeFile, PYTHON_PROJECT_FILES[activeFile])}
              className="px-3 py-1.5 rounded-lg text-xs font-medium text-white bg-indigo-600 hover:bg-indigo-500 transition flex items-center gap-1"
            >
              <Download className="w-3.5 h-3.5" />
              Download File
            </button>
          </div>
        </div>

        {/* Workspace tabs & Editor area */}
        <div id="viewer-content" className="flex-1 flex overflow-hidden">
          {/* File selector sidebar */}
          <div id="viewer-sidebar" className="w-64 bg-slate-950 border-r border-slate-800 py-3 flex flex-col">
            <div className="px-4 py-2 text-[10px] font-bold text-slate-500 uppercase tracking-wider">
              Project Structure
            </div>
            <div className="flex-1 overflow-y-auto px-2 space-y-1 mt-1">
              {Object.keys(PYTHON_PROJECT_FILES).map((filename) => (
                <button
                  key={filename}
                  onClick={() => setActiveFile(filename as keyof typeof PYTHON_PROJECT_FILES)}
                  className={`w-full text-left px-3 py-2 rounded-lg text-xs font-mono transition flex items-center gap-2 ${
                    activeFile === filename
                      ? "bg-indigo-950/50 text-indigo-300 border-l-2 border-indigo-500"
                      : "text-slate-400 hover:text-slate-200 hover:bg-slate-900"
                  }`}
                >
                  <FileCode className={`w-3.5 h-3.5 ${activeFile === filename ? "text-indigo-400" : "text-slate-500"}`} />
                  {filename}
                </button>
              ))}
            </div>
            
            <div className="p-3 m-2 rounded-lg bg-slate-900 border border-slate-800 text-[10px] text-slate-400">
              <div className="font-semibold text-slate-300 flex items-center gap-1 mb-1">
                <HelpCircle className="w-3 h-3 text-indigo-400" />
                Dual DB Setup
              </div>
              Runs inSQLite local mode by default! No MySQL server setup needed for quick evaluation.
            </div>
          </div>

          {/* Interactive Code Editor (Read Only) */}
          <div id="viewer-editor" className="flex-1 bg-slate-950 text-slate-300 overflow-auto p-6 font-mono text-xs leading-relaxed">
            <pre className="whitespace-pre">{PYTHON_PROJECT_FILES[activeFile]}</pre>
          </div>
        </div>
      </div>
    </div>
  );
}
