import React, { useState } from "react";
import { PortfolioItem, Stock } from "../types";
import { Plus, Trash2, Calendar, DollarSign, ListFilter, TrendingUp, TrendingDown } from "lucide-react";

interface PortfolioManagerProps {
  portfolio: PortfolioItem[];
  liveStocks: Record<string, Stock>;
  onAddPosition: (ticker: string, shares: number, price: number, date: string) => void;
  onRemovePosition: (id: string) => void;
}

export default function PortfolioManager({
  portfolio,
  liveStocks,
  onAddPosition,
  onRemovePosition
}: PortfolioManagerProps) {
  const [ticker, setTicker] = useState("AAPL");
  const [shares, setShares] = useState<number>(10);
  const [price, setPrice] = useState<number>(180);
  const [date, setDate] = useState(new Date().toISOString().split("T")[0]);
  const [error, setError] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!ticker) {
      setError("Please select a ticker.");
      return;
    }
    if (shares <= 0) {
      setError("Shares must be greater than zero.");
      return;
    }
    if (price <= 0) {
      setError("Price must be greater than zero.");
      return;
    }
    
    onAddPosition(ticker, shares, price, date);
    setError("");
    // Reset defaults or show brief confirmation
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
      {/* Transaction Entry Form */}
      <div className="bg-[#16181C] rounded-2xl border border-slate-800 p-6 shadow-lg h-fit">
        <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
          <Plus className="w-5 h-5 text-indigo-400" />
          Log Stock Transaction
        </h3>

        {error && (
          <div className="mb-4 p-3 bg-red-500/10 text-red-400 text-xs rounded-xl font-medium border border-red-500/20">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">
              Select Ticker Symbol
            </label>
            <div className="relative">
              <select
                value={ticker}
                onChange={(e) => setTicker(e.target.value)}
                className="w-full rounded-xl border border-slate-800 px-4 py-3 bg-[#111418] text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition cursor-pointer"
              >
                {Object.keys(liveStocks).map((sym) => (
                  <option key={sym} value={sym} className="bg-[#16181C] text-white">
                    {sym} - {liveStocks[sym].name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">
                Shares Quantity
              </label>
              <div className="relative">
                <input
                  type="number"
                  step="any"
                  value={shares}
                  onChange={(e) => setShares(parseFloat(e.target.value) || 0)}
                  className="w-full rounded-xl border border-slate-800 pl-4 pr-3 py-3 bg-[#111418] text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">
                Purchase Price ($)
              </label>
              <div className="relative">
                <input
                  type="number"
                  step="any"
                  value={price}
                  onChange={(e) => setPrice(parseFloat(e.target.value) || 0)}
                  className="w-full rounded-xl border border-slate-800 pl-4 pr-3 py-3 bg-[#111418] text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition"
                />
              </div>
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">
              Transaction Date
            </label>
            <div className="relative">
              <input
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full rounded-xl border border-slate-800 px-4 py-3 bg-[#111418] text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition"
              />
            </div>
          </div>

          <button
            type="submit"
            className="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-medium text-sm py-3 px-4 rounded-xl shadow-lg shadow-indigo-500/10 transition-all duration-200 flex items-center justify-center gap-2 cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            Commit to Registry
          </button>
        </form>
      </div>

      {/* Holdings List View */}
      <div className="lg:col-span-2 bg-[#16181C] rounded-2xl border border-slate-800 p-6 shadow-lg">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-semibold text-white flex items-center gap-2">
            <ListFilter className="w-5 h-5 text-indigo-400" />
            Active Transaction Registry
          </h3>
          <span className="text-xs font-mono text-slate-400 bg-[#111418] px-2.5 py-1 rounded-md border border-slate-800">
            Total Positions: {portfolio.length}
          </span>
        </div>

        {portfolio.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 text-center border-2 border-dashed border-slate-800 rounded-xl">
            <div className="w-12 h-12 rounded-full bg-[#111418] flex items-center justify-center mb-3">
              <DollarSign className="w-6 h-6 text-slate-500" />
            </div>
            <p className="text-slate-400 text-sm font-medium">No recorded transactions yet.</p>
            <p className="text-slate-500 text-xs mt-1">Use the entry form to log your stock purchases.</p>
          </div>
        ) : (
          <div className="space-y-4 overflow-y-auto max-h-[480px] pr-2">
            {portfolio.map((item) => {
              const live = liveStocks[item.ticker];
              const curPrice = live ? live.price : item.purchasePrice;
              const costBasis = item.shares * item.purchasePrice;
              const marketValue = item.shares * curPrice;
              const pl = marketValue - costBasis;
              const plPercent = (pl / costBasis) * 100;
              const isGain = pl >= 0;

              return (
                <div
                  key={item.id}
                  className="p-4 rounded-xl border border-slate-800 hover:border-slate-700 bg-slate-900/40 transition flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4"
                >
                  <div className="flex items-start gap-3">
                    <div className="w-10 h-10 rounded-lg bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center font-bold text-indigo-400 text-sm">
                      {item.ticker}
                    </div>
                    <div>
                      <div className="flex items-center gap-1.5">
                        <span className="font-semibold text-white text-sm">{item.ticker}</span>
                        <span className="text-xs text-slate-500">({live?.name || "Asset"})</span>
                      </div>
                      <div className="flex items-center gap-2 mt-1 text-xs text-slate-400">
                        <span className="flex items-center gap-0.5 font-medium text-slate-300">
                          {item.shares} shares
                        </span>
                        <span className="text-slate-600">•</span>
                        <span className="text-slate-300">Buy: ${item.purchasePrice.toFixed(2)}</span>
                        <span className="text-slate-600">•</span>
                        <span className="flex items-center gap-0.5 text-slate-300">
                          <Calendar className="w-3 h-3 text-slate-500" />
                          {item.purchaseDate}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Financial computations */}
                  <div className="flex items-center justify-between sm:justify-end w-full sm:w-auto gap-6 border-t sm:border-t-0 pt-3 sm:pt-0 border-slate-800">
                    <div className="text-right">
                      <div className="text-xs text-slate-500 font-medium">Market Value</div>
                      <div className="text-sm font-semibold text-white mt-0.5">
                        ${marketValue.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                      </div>
                    </div>

                    <div className="text-right min-w-[80px]">
                      <div className="text-xs text-slate-500 font-medium">P/L</div>
                      <div className={`text-xs font-semibold flex items-center justify-end gap-0.5 mt-0.5 ${isGain ? "text-emerald-400" : "text-rose-400"}`}>
                        {isGain ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
                        {isGain ? "+" : ""}{pl.toFixed(2)} ({isGain ? "+" : ""}{plPercent.toFixed(1)}%)
                      </div>
                    </div>

                    <button
                      onClick={() => onRemovePosition(item.id)}
                      className="p-2 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 border border-transparent hover:border-rose-500/20 transition cursor-pointer"
                      title="Delete Transaction Record"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
