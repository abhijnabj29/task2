import { useState } from "react";
import { PortfolioItem, Stock, StockHistoryItem } from "../types";
import { Sparkles, Brain, Cpu, TrendingUp, TrendingDown, RefreshCw, ChevronRight } from "lucide-react";

interface AIAdvisorProps {
  portfolio: PortfolioItem[];
  liveStocks: Record<string, Stock>;
  history: Record<string, StockHistoryItem[]>;
}

// Simple but elegant Markdown formatter to output polished HTML blocks safely
function renderMarkdown(md: string) {
  if (!md) return null;
  const lines = md.split("\n");
  return lines.map((line, idx) => {
    // Headers
    if (line.startsWith("### ")) {
      return (
        <h4 key={idx} className="text-base font-bold text-white mt-5 mb-2 border-b border-slate-800 pb-1">
          {line.replace("### ", "")}
        </h4>
      );
    }
    if (line.startsWith("#### ")) {
      return (
        <h5 key={idx} className="text-sm font-bold text-slate-200 mt-4 mb-2">
          {line.replace("#### ", "")}
        </h5>
      );
    }
    // Bullet points
    if (line.trim().startsWith("- ")) {
      const cleanText = line.trim().replace("- ", "");
      // Support nested bolding e.g. **Current Assessment**
      return (
        <li key={idx} className="text-xs text-slate-300 list-disc ml-5 mb-1.5 leading-relaxed">
          {parseInlineFormatting(cleanText)}
        </li>
      );
    }
    // Warning blocks
    if (line.trim().startsWith("⚠️")) {
      return (
        <div key={idx} className="p-3 bg-amber-500/10 border border-amber-500/20 rounded-xl text-amber-300 text-xs my-3 flex items-start gap-2">
          <span className="text-sm">⚠️</span>
          <p className="flex-1 font-medium">{line.replace("⚠️", "").trim()}</p>
        </div>
      );
    }
    // Plain text / paragraph
    if (line.trim() === "") return <div key={idx} className="h-2" />;
    return (
      <p key={idx} className="text-xs text-slate-300 mb-2 leading-relaxed">
        {parseInlineFormatting(line)}
      </p>
    );
  });
}

function parseInlineFormatting(text: string) {
  const parts = text.split("`");
  return parts.map((part, i) => {
    // Alternate code styling
    if (i % 2 !== 0) {
      return <code key={i} className="bg-slate-800 px-1 py-0.5 rounded text-[10px] font-mono text-indigo-300 font-semibold">{part}</code>;
    }
    
    // Bold styling
    const subParts = part.split("**");
    return subParts.map((subPart, j) => {
      if (j % 2 !== 0) {
        return <strong key={j} className="font-bold text-white">{subPart}</strong>;
      }
      return subPart;
    });
  });
}

export default function AIAdvisor({ portfolio, liveStocks, history }: AIAdvisorProps) {
  const [riskProfile, setRiskProfile] = useState("Moderate");
  const [investmentGoal, setInvestmentGoal] = useState("Balanced Growth");
  const [report, setReport] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [isSimulated, setIsSimulated] = useState(false);

  // Scikit-learn trend prediction equivalent (slope projection) on the past 30 days of history
  const predictPriceTrend = (ticker: string) => {
    const tickerHist = history[ticker];
    if (!tickerHist || tickerHist.length < 5) return { trend: "Hold", percent: 0, target: 0 };

    // Simple Linear Regression slope calculation
    const n = tickerHist.length;
    let sumX = 0;
    let sumY = 0;
    let sumXY = 0;
    let sumXX = 0;

    tickerHist.forEach((item, index) => {
      const x = index;
      const y = item.price;
      sumX += x;
      sumY += y;
      sumXY += x * y;
      sumXX += x * x;
    });

    const slope = (n * sumXY - sumX * sumY) / (n * sumXX - sumX * sumX);
    const lastPrice = tickerHist[n - 1].price;
    
    // Project 15 days ahead
    const predPrice = lastPrice + slope * 15;
    const changePct = ((predPrice - lastPrice) / lastPrice) * 100;

    let trend = "Consolidating";
    if (slope > 0.08 && changePct > 1.5) trend = "Bullish";
    else if (slope < -0.08 && changePct < -1.5) trend = "Bearish";

    return {
      trend,
      percent: changePct,
      target: predPrice
    };
  };

  const handleGenerateReport = async () => {
    setLoading(true);
    try {
      const response = await fetch("/api/recommendations", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          portfolio,
          riskProfile,
          investmentGoal
        })
      });
      const data = await response.json();
      setReport(data.text);
      setIsSimulated(!!data.isSimulated);
    } catch (err) {
      console.error(err);
      setReport("### ⚠️ API Error\nFailed to receive advice from the Gemini platform server.");
    } finally {
      setLoading(false);
    }
  };

  const activeHoldings = Array.from(new Set(portfolio.map((p) => p.ticker)));

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
      {/* Parameters Panel */}
      <div className="lg:col-span-4 space-y-6">
        <div className="bg-[#16181C] rounded-2xl border border-slate-800 p-6 shadow-lg">
          <h3 className="text-base font-semibold text-white mb-4 flex items-center gap-2">
            <Cpu className="w-5 h-5 text-indigo-400" />
            Advisory Directives
          </h3>

          <div className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">
                Risk Profile Policy
              </label>
              <div className="grid grid-cols-3 gap-2">
                {["Conservative", "Moderate", "Aggressive"].map((level) => (
                  <button
                    key={level}
                    onClick={() => setRiskProfile(level)}
                    className={`px-3 py-2 text-xs font-medium rounded-lg border transition cursor-pointer text-center ${
                      riskProfile === level
                        ? "bg-indigo-600 text-white border-indigo-600 shadow-lg shadow-indigo-500/10"
                        : "bg-[#111418] border-slate-800 text-slate-400 hover:border-slate-700"
                    }`}
                  >
                    {level}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">
                Strategic Goal
              </label>
              <select
                value={investmentGoal}
                onChange={(e) => setInvestmentGoal(e.target.value)}
                className="w-full rounded-xl border border-slate-800 px-4 py-3 bg-[#111418] text-white text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition cursor-pointer"
              >
                <option value="Capital Preservation" className="bg-[#16181C] text-white">Capital Preservation</option>
                <option value="Balanced Growth" className="bg-[#16181C] text-white">Balanced Growth & Dividend Reinvestment</option>
                <option value="Aggressive Alpha" className="bg-[#16181C] text-white">Aggressive Asset Accrual (Alpha Search)</option>
              </select>
            </div>

            <button
              onClick={handleGenerateReport}
              disabled={loading}
              className="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs py-3 px-4 rounded-xl shadow-lg shadow-indigo-500/10 transition duration-200 flex items-center justify-center gap-2 disabled:opacity-50 cursor-pointer"
            >
              {loading ? (
                <RefreshCw className="w-4 h-4 animate-spin text-indigo-200" />
              ) : (
                <Sparkles className="w-4 h-4 text-indigo-200" />
              )}
              {loading ? "Analyzing Portfolios..." : "Synthesize AI Advisory Brief"}
            </button>
          </div>
        </div>

        {/* Machine learning predictions list */}
        <div className="bg-[#16181C] rounded-2xl border border-slate-800 p-6 shadow-lg">
          <h3 className="text-base font-semibold text-white mb-1 flex items-center gap-2">
            <Brain className="w-5 h-5 text-emerald-400" />
            Machine Learning Price Projections
          </h3>
          <p className="text-[11px] text-slate-500 mb-4">
            Scikit-Learn-equivalent 15-day forward projection models.
          </p>

          <div className="space-y-3">
            {(activeHoldings.length > 0 ? activeHoldings : ["AAPL", "MSFT", "NVDA"]).slice(0, 4).map((tick) => {
              const { trend, percent, target } = predictPriceTrend(tick);
              const isUp = trend === "Bullish";
              const isDown = trend === "Bearish";
              
              return (
                <div key={tick} className="p-3 rounded-xl border border-slate-800 bg-slate-900/40 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-xs text-white bg-slate-850 px-2 py-1 rounded">{tick}</span>
                    <span className="text-[10px] text-slate-500">15-day target: ${target.toFixed(2)}</span>
                  </div>
                  <span className={`inline-flex items-center gap-0.5 text-xs font-semibold ${isUp ? "text-emerald-400" : isDown ? "text-rose-400" : "text-amber-400"}`}>
                    {isUp ? <TrendingUp className="w-3.5 h-3.5" /> : isDown ? <TrendingDown className="w-3.5 h-3.5" /> : null}
                    {trend} ({percent > 0 ? "+" : ""}{percent.toFixed(1)}%)
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Advisory Report View */}
      <div className="lg:col-span-8 bg-[#16181C] rounded-2xl border border-slate-800 p-6 shadow-lg flex flex-col justify-between min-h-[450px]">
        <div>
          <div className="flex items-center justify-between border-b border-slate-800 pb-4 mb-4">
            <h3 className="text-base font-semibold text-white flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-indigo-400" />
              Executive Advisory Synthesis
            </h3>
            {report && (
              <span className={`text-[10px] font-semibold px-2.5 py-1 rounded-full ${isSimulated ? "bg-amber-500/10 text-amber-400 border border-amber-500/20" : "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20"}`}>
                {isSimulated ? "Simulation Engine" : "Gemini 3.5 Live"}
              </span>
            )}
          </div>

          {!report && !loading ? (
            <div className="flex flex-col items-center justify-center py-20 text-center">
              <div className="w-12 h-12 rounded-full bg-[#111418] flex items-center justify-center mb-4">
                <Brain className="w-6 h-6 text-slate-600" />
              </div>
              <p className="text-slate-400 font-medium text-sm">Advisory desk is idle.</p>
              <p className="text-slate-500 text-xs mt-1">Configure your variables and trigger the Synthesis command.</p>
            </div>
          ) : loading ? (
            <div className="space-y-6 py-4 animate-pulse">
              <div className="h-4 bg-slate-800 rounded w-1/3"></div>
              <div className="space-y-3">
                <div className="h-3 bg-slate-800 rounded"></div>
                <div className="h-3 bg-slate-800 rounded w-5/6"></div>
                <div className="h-3 bg-slate-800 rounded w-4/5"></div>
              </div>
              <div className="h-4 bg-slate-800 rounded w-1/4 mt-8"></div>
              <div className="space-y-3">
                <div className="h-3 bg-slate-800 rounded w-11/12"></div>
                <div className="h-3 bg-slate-800 rounded"></div>
              </div>
            </div>
          ) : (
            <div className="prose max-w-none text-slate-300">
              {renderMarkdown(report || "")}
            </div>
          )}
        </div>

        {report && (
          <div className="mt-8 p-3 rounded-xl bg-[#111418] border border-slate-800 text-[10px] text-slate-500 flex items-center gap-2">
            <span className="font-semibold text-slate-400">Quantitative Disclaimer:</span>
            Machine Learning projections and LLM synthesis constitute algorithmic support patterns, not explicit financial advice or capital directives.
          </div>
        )}
      </div>
    </div>
  );
}
