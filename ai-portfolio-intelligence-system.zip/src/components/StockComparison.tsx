import { useState } from "react";
import { Stock, StockHistoryItem } from "../types";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";
import { LineChart as ChartIcon, CheckSquare, Square, TrendingUp, HelpCircle } from "lucide-react";

interface StockComparisonProps {
  liveStocks: Record<string, Stock>;
  history: Record<string, StockHistoryItem[]>;
}

export default function StockComparison({ liveStocks, history }: StockComparisonProps) {
  const [selectedTickers, setSelectedTickers] = useState<string[]>(["AAPL", "MSFT", "NVDA"]);

  const toggleTicker = (ticker: string) => {
    if (selectedTickers.includes(ticker)) {
      if (selectedTickers.length > 1) {
        setSelectedTickers(selectedTickers.filter((t) => t !== ticker));
      }
    } else {
      setSelectedTickers([...selectedTickers, ticker]);
    }
  };

  // Restructure history for Recharts LineChart
  // Out: Array of { date: string, AAPL: number, MSFT: number }
  const getChartData = () => {
    if (selectedTickers.length === 0) return [];
    
    const sampleHistory = history[selectedTickers[0]];
    if (!sampleHistory) return [];

    return sampleHistory.map((item, idx) => {
      const dataPoint: any = { date: item.date };
      
      selectedTickers.forEach((tick) => {
        const tickHist = history[tick];
        if (tickHist && tickHist[idx]) {
          // Normalize to base 100 on start date (idx 0)
          const startVal = tickHist[0].price;
          const currentVal = tickHist[idx].price;
          dataPoint[tick] = parseFloat(((currentVal / startVal) * 100).toFixed(2));
        }
      });
      
      return dataPoint;
    });
  };

  const chartData = getChartData();
  const LINE_COLORS = ["#6366F1", "#10B981", "#EF4444", "#F59E0B", "#8B5CF6", "#EC4899", "#06B6D4"];

  return (
    <div className="bg-[#16181C] rounded-2xl border border-slate-800 p-6 shadow-lg space-y-6">
      <div className="flex flex-wrap justify-between items-center gap-4">
        <div>
          <h3 className="text-lg font-semibold text-white flex items-center gap-2">
            <ChartIcon className="w-5 h-5 text-indigo-400" />
            Historical Normalized Comparison (Rebased to 100)
          </h3>
          <p className="text-slate-400 text-xs mt-1">
            Rebases stock prices to 100 at start index. Excellent for tracing relative cumulative returns of multiple assets over a 30-day lookback interval.
          </p>
        </div>
      </div>

      {/* Selectors grid */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 p-4 bg-slate-900/50 rounded-xl border border-slate-800">
        {Object.keys(liveStocks).map((ticker) => {
          const isSelected = selectedTickers.includes(ticker);
          return (
            <button
              key={ticker}
              onClick={() => toggleTicker(ticker)}
              className={`flex items-center gap-2 p-2.5 rounded-lg text-xs font-medium border transition cursor-pointer text-left ${
                isSelected
                  ? "bg-indigo-600/15 border-indigo-500/30 text-indigo-400 shadow-lg shadow-indigo-500/5"
                  : "bg-[#111418] border-slate-800 text-slate-400 hover:border-slate-700 hover:text-white"
              }`}
            >
              {isSelected ? (
                <CheckSquare className="w-4 h-4 text-indigo-400 shrink-0" />
              ) : (
                <Square className="w-4 h-4 text-slate-600 shrink-0" />
              )}
              <div className="truncate">
                <div className="font-bold">{ticker}</div>
                <div className="text-[10px] text-slate-500 truncate">{liveStocks[ticker].name}</div>
              </div>
            </button>
          );
        })}
      </div>

      {/* Chart Canvas */}
      <div className="h-[320px] w-full border border-slate-800 rounded-xl p-4 bg-slate-900/40">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={chartData} margin={{ left: -10, right: 10, top: 10, bottom: 5 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#1E293B" />
            <XAxis dataKey="date" stroke="#475569" fontSize={10} tickLine={false} />
            <YAxis stroke="#475569" fontSize={10} tickLine={false} domain={["auto", "auto"]} />
            <Tooltip />
            <Legend wrapperStyle={{ fontSize: "10px", marginTop: "10px" }} />
            {selectedTickers.map((ticker, idx) => (
              <Line
                key={ticker}
                type="monotone"
                dataKey={ticker}
                stroke={LINE_COLORS[idx % LINE_COLORS.length]}
                strokeWidth={2}
                dot={false}
                activeDot={{ r: 5 }}
              />
            ))}
          </LineChart>
        </ResponsiveContainer>
      </div>

      {/* Comparative Quant Matrix */}
      <div className="border border-slate-800 rounded-xl overflow-hidden">
        <table className="w-full text-left text-xs border-collapse">
          <thead>
            <tr className="bg-slate-900/50 text-slate-400 font-semibold border-b border-slate-800">
              <th className="p-3">Asset</th>
              <th className="p-3">Current Quote</th>
              <th className="p-3">30-day Volatility</th>
              <th className="p-3">Beta Index</th>
              <th className="p-3">Trend Signal</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800 text-slate-300">
            {selectedTickers.map((ticker) => {
              const live = liveStocks[ticker];
              const isGain = live ? live.change >= 0 : true;
              return (
                <tr key={ticker} className="hover:bg-slate-800/30">
                  <td className="p-3 font-semibold text-white">{ticker}</td>
                  <td className="p-3">
                    ${live?.price.toFixed(2)}
                    <span className={`text-[10px] ml-1.5 font-medium ${isGain ? "text-emerald-400" : "text-rose-400"}`}>
                      {isGain ? "+" : ""}{live?.changePercent.toFixed(1)}%
                    </span>
                  </td>
                  <td className="p-3 font-mono text-slate-500">{(live?.volatility * 100).toFixed(1)}%</td>
                  <td className="p-3 font-mono font-medium text-slate-400">{live?.beta.toFixed(2)}</td>
                  <td className="p-3">
                    <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold ${
                      live?.beta > 1.3
                        ? "bg-rose-500/10 text-rose-400 border border-rose-500/20"
                        : live?.beta < 1.0
                        ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20"
                        : "bg-indigo-500/10 text-indigo-400 border border-indigo-500/20"
                    }`}>
                      {live?.beta > 1.3 ? "Aggressive (Bullish Target)" : live?.beta < 1.0 ? "Defensive Value" : "Core Momentum"}
                    </span>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
