import React, { useState } from "react";
import { Stock, AlertNotification, AlertRule } from "../types";
import { Mail, Bell, ShieldAlert, Plus, Trash2, Send, Check } from "lucide-react";

interface AlertsSimulatorProps {
  liveStocks: Record<string, Stock>;
  notifications: AlertNotification[];
  rules: AlertRule[];
  onAddRule: (ticker: string, type: "ABOVE" | "BELOW", threshold: number, email: string) => void;
  onRemoveRule: (id: string) => void;
  onTriggerSimulatedNotification: (ruleIndex: number) => void;
}

export default function AlertsSimulator({
  liveStocks,
  notifications,
  rules,
  onAddRule,
  onRemoveRule,
  onTriggerSimulatedNotification
}: AlertsSimulatorProps) {
  const [ticker, setTicker] = useState("AAPL");
  const [type, setType] = useState<"ABOVE" | "BELOW">("ABOVE");
  const [threshold, setThreshold] = useState<number>(195);
  const [email, setEmail] = useState("nagrajkc6@gmail.com");
  const [copiedNotificationId, setCopiedNotificationId] = useState<string | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!ticker || !email || !threshold) return;
    onAddRule(ticker, type, threshold, email);
  };

  const handleCopyAlert = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedNotificationId(id);
    setTimeout(() => setCopiedNotificationId(null), 2000);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
      {/* Alert Creator Form */}
      <div className="lg:col-span-4 bg-[#16181C] rounded-2xl border border-slate-800 p-6 shadow-lg h-fit space-y-6">
        <div>
          <h3 className="text-base font-semibold text-white mb-1 flex items-center gap-2">
            <Bell className="w-5 h-5 text-indigo-400" />
            Set Notification Rules
          </h3>
          <p className="text-[11px] text-slate-500">
            Establish automated watchers. Triggers system warnings and push simulations upon condition breach.
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">
              Select Watch Stock
            </label>
            <select
              value={ticker}
              onChange={(e) => setTicker(e.target.value)}
              className="w-full rounded-xl border border-slate-800 px-4 py-3 bg-[#111418] text-white text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition cursor-pointer"
            >
              {Object.keys(liveStocks).map((sym) => (
                <option key={sym} value={sym} className="bg-[#16181C] text-white">
                  {sym} - current: ${liveStocks[sym].price.toFixed(2)}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">
              Direction Threshold
            </label>
            <div className="grid grid-cols-2 gap-2">
              {(["ABOVE", "BELOW"] as const).map((dir) => (
                <button
                  key={dir}
                  type="button"
                  onClick={() => setType(dir)}
                  className={`py-2 px-3 text-xs font-semibold rounded-lg border transition cursor-pointer text-center ${
                    type === dir
                      ? "bg-indigo-600 border-indigo-600 text-white shadow-lg shadow-indigo-500/10"
                      : "bg-[#111418] border-slate-800 text-slate-400 hover:border-slate-700"
                  }`}
                >
                  {dir === "ABOVE" ? "Crosses ABOVE" : "Falls BELOW"}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">
                Trigger Price Value ($)
              </label>
              <input
                type="number"
                step="any"
                value={threshold}
                onChange={(e) => setThreshold(parseFloat(e.target.value) || 0)}
                className="w-full rounded-xl border border-slate-800 px-4 py-3 bg-[#111418] text-white text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">
              SMTP Target Email Address
            </label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="e.g. user@domain.com"
              className="w-full rounded-xl border border-slate-800 px-4 py-3 bg-[#111418] text-white text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition"
            />
          </div>

          <button
            type="submit"
            className="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-medium text-xs py-3 px-4 rounded-xl shadow-lg shadow-indigo-500/10 transition duration-200 flex items-center justify-center gap-2 cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            Append Watch Rule
          </button>
        </form>
      </div>

      {/* Rules list & Simulation logs */}
      <div className="lg:col-span-8 space-y-6">
        {/* Rules Table */}
        <div className="bg-[#16181C] rounded-2xl border border-slate-800 p-6 shadow-lg">
          <h3 className="text-base font-semibold text-white mb-4 flex items-center gap-2">
            <ShieldAlert className="w-5 h-5 text-indigo-400" />
            Active Warning Threshold Rules
          </h3>

          {rules.length === 0 ? (
            <div className="text-slate-500 text-xs py-10 text-center border border-dashed border-slate-800 rounded-xl">
              No alert configurations logged. Add rules to observe conditions.
            </div>
          ) : (
            <div className="space-y-3 max-h-[220px] overflow-y-auto pr-2">
              {rules.map((rule, idx) => (
                <div
                  key={rule.id}
                  className="p-3 bg-slate-900/50 rounded-xl border border-slate-800 flex items-center justify-between text-xs"
                >
                  <div className="flex items-center gap-3">
                    <span className="font-bold text-indigo-300 bg-indigo-500/10 border border-indigo-500/20 px-2 py-0.5 rounded">
                      {rule.ticker}
                    </span>
                    <span className="text-slate-300 font-medium">
                      If price goes <strong className="text-white">{rule.type}</strong> ${rule.threshold.toFixed(2)}
                    </span>
                    <span className="text-slate-500 truncate hidden sm:inline-block">({rule.email})</span>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => onTriggerSimulatedNotification(idx)}
                      className="px-2.5 py-1.5 rounded-lg bg-indigo-500/10 hover:bg-indigo-500/20 text-indigo-300 border border-indigo-500/20 font-semibold text-[10px] flex items-center gap-1 transition"
                      title="Trigger SMTP simulation warning"
                    >
                      <Send className="w-3 h-3" />
                      Test Alert
                    </button>
                    <button
                      onClick={() => onRemoveRule(rule.id)}
                      className="p-1.5 rounded-lg text-slate-500 hover:text-rose-400 hover:bg-rose-500/10 transition"
                      title="Remove condition"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Notifications push log */}
        <div className="bg-[#16181C] rounded-2xl border border-slate-800 p-6 shadow-lg">
          <h3 className="text-base font-semibold text-white mb-4 flex items-center gap-2">
            <Mail className="w-5 h-5 text-emerald-400" />
            Simulated SMTP Email Outbox Logs
          </h3>

          {notifications.length === 0 ? (
            <div className="text-slate-500 text-xs py-10 text-center border border-dashed border-slate-800 rounded-xl">
              No mail triggers captured. Append alert watches or run Test Alerts to fire simulations.
            </div>
          ) : (
            <div className="space-y-3 max-h-[220px] overflow-y-auto pr-2">
              {notifications.map((notif) => (
                <div
                  key={notif.id}
                  onClick={() => handleCopyAlert(notif.message, notif.id)}
                  className="p-3 bg-slate-900/20 hover:bg-slate-850/50 rounded-xl border border-slate-800 flex justify-between gap-4 text-xs cursor-pointer transition"
                >
                  <div className="flex items-start gap-3 flex-1 min-w-0">
                    <div className="w-2 h-2 rounded-full bg-emerald-500 mt-1.5 shrink-0"></div>
                    <div className="min-w-0">
                      <div className="font-semibold text-white truncate">{notif.message}</div>
                      <div className="text-[10px] text-slate-500 font-mono mt-0.5">{notif.timestamp} • Status: {notif.status}</div>
                    </div>
                  </div>
                  <button className="text-slate-500 shrink-0">
                    {copiedNotificationId === notif.id ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Mail className="w-3.5 h-3.5" />}
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
