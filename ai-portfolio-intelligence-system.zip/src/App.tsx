import React, { useState, useEffect } from "react";
import { Stock, PortfolioItem, StockHistoryItem, AlertNotification, AlertRule } from "./types";
import PortfolioManager from "./components/PortfolioManager";
import RiskDashboard from "./components/RiskDashboard";
import StockComparison from "./components/StockComparison";
import AIAdvisor from "./components/AIAdvisor";
import AlertsSimulator from "./components/AlertsSimulator";
import ProjectCodeExporter from "./components/ProjectCodeExporter";
import { 
  TrendingUp, 
  TrendingDown, 
  DollarSign, 
  ShieldAlert, 
  Activity, 
  User, 
  Settings, 
  FileSpreadsheet, 
  FileText, 
  RefreshCw,
  LogOut,
  Sparkles,
  PieChart,
  Code
} from "lucide-react";

export default function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [username, setUsername] = useState("DemoInvestor");
  const [email, setEmail] = useState("nagrajkc6@gmail.com");
  const [password, setPassword] = useState("password123");
  const [isRegistering, setIsRegistering] = useState(false);

  // Active Workspace Tab
  const [activeTab, setActiveTab] = useState<"dashboard" | "portfolio" | "advisor" | "comparison" | "alerts" | "python">("dashboard");

  // Dynamic Portfolio Holdings
  const [portfolio, setPortfolio] = useState<PortfolioItem[]>([
    { id: "1", ticker: "AAPL", shares: 15, purchasePrice: 175.50, purchaseDate: "2026-04-10" },
    { id: "2", ticker: "MSFT", shares: 8, purchasePrice: 395.20, purchaseDate: "2026-05-15" },
    { id: "3", ticker: "NVDA", shares: 12, purchasePrice: 820.00, purchaseDate: "2026-06-02" },
    { id: "4", ticker: "BRK_B", shares: 10, purchasePrice: 380.10, purchaseDate: "2026-06-20" }
  ]);

  // Live and Historical Stocks Feed
  const [liveStocks, setLiveStocks] = useState<Record<string, Stock>>({});
  const [history, setHistory] = useState<Record<string, StockHistoryItem[]>>({});
  const [isRefreshing, setIsRefreshing] = useState(false);

  // Rules and Push Notification lists
  const [alertRules, setAlertRules] = useState<AlertRule[]>([
    { id: "r1", ticker: "AAPL", type: "ABOVE", threshold: 190, email: "nagrajkc6@gmail.com" },
    { id: "r2", ticker: "NVDA", type: "BELOW", threshold: 850, email: "nagrajkc6@gmail.com" }
  ]);
  const [notifications, setNotifications] = useState<AlertNotification[]>([]);

  // Periodically fetch live prices from our server endpoint
  const fetchStockPrices = async (silent = false) => {
    if (!silent) setIsRefreshing(true);
    try {
      const response = await fetch("/api/stocks");
      const data = await response.json();
      setLiveStocks(data.live);
      setHistory(data.history);
      
      // Perform automated checks against our active alert rules
      checkAlertConditions(data.live);
    } catch (err) {
      console.error("Failed to load stock feed from Express server:", err);
    } finally {
      if (!silent) setIsRefreshing(false);
    }
  };

  useEffect(() => {
    fetchStockPrices();
    
    // Auto-refresh quotes every 10 seconds to feel live and real-time
    const interval = setInterval(() => {
      fetchStockPrices(true);
    }, 10000);
    
    return () => clearInterval(interval);
  }, [alertRules]);

  // Alert triggers checker
  const checkAlertConditions = (currentPrices: Record<string, Stock>) => {
    alertRules.forEach((rule) => {
      const live = currentPrices[rule.ticker];
      if (!live) return;

      const crossedAbove = rule.type === "ABOVE" && live.price > rule.threshold;
      const crossedBelow = rule.type === "BELOW" && live.price < rule.threshold;

      if (crossedAbove || crossedBelow) {
        const conditionText = crossedAbove ? "crossed above" : "fell below";
        const msg = `🚨 [BREACH ALERT] ${rule.ticker} has ${conditionText} your warning threshold of $${rule.threshold.toFixed(2)}. Current: $${live.price.toFixed(2)}.`;
        
        // Prevent spam: only add notification if it doesn't already exist in active buffer recently
        setNotifications((prev) => {
          const duplicate = prev.some((n) => n.message === msg);
          if (duplicate) return prev;

          // Push simulation warning toast
          console.log(`Sending SMTP Simulation email alert to ${rule.email}`);
          return [
            {
              id: Math.random().toString(),
              timestamp: new Date().toLocaleTimeString(),
              ticker: rule.ticker,
              type: crossedAbove ? "PRICE_ABOVE" : "PRICE_BELOW",
              message: msg,
              status: "SENT"
            },
            ...prev
          ];
        });
      }
    });
  };

  // Portfolio Handlers
  const handleAddPosition = (ticker: string, shares: number, price: number, date: string) => {
    const newItem: PortfolioItem = {
      id: Math.random().toString(),
      ticker,
      shares,
      purchasePrice: price,
      purchaseDate: date
    };
    setPortfolio((prev) => [...prev, newItem]);
  };

  const handleRemovePosition = (id: string) => {
    setPortfolio((prev) => prev.filter((item) => item.id !== id));
  };

  // Watcher Rules Handlers
  const handleAddRule = (ticker: string, type: "ABOVE" | "BELOW", threshold: number, targetEmail: string) => {
    const newRule: AlertRule = {
      id: Math.random().toString(),
      ticker,
      type,
      threshold,
      email: targetEmail
    };
    setAlertRules((prev) => [...prev, newRule]);
  };

  const handleRemoveRule = (id: string) => {
    setAlertRules((prev) => prev.filter((r) => r.id !== id));
  };

  const handleTriggerSimulatedNotification = (ruleIndex: number) => {
    const rule = alertRules[ruleIndex];
    if (!rule) return;
    
    const live = liveStocks[rule.ticker];
    const priceNow = live ? live.price : rule.threshold * 1.02;

    const msg = `✉️ Simulated SMTP Email Dispatch to <${rule.email}>: Warning triggered! ${rule.ticker} price threshold breach alert. Threshold: $${rule.threshold.toFixed(2)}, Current quote: $${priceNow.toFixed(2)}.`;
    
    setNotifications((prev) => [
      {
        id: Math.random().toString(),
        timestamp: new Date().toLocaleTimeString(),
        ticker: rule.ticker,
        type: rule.type === "ABOVE" ? "PRICE_ABOVE" : "PRICE_BELOW",
        message: msg,
        status: "SENT"
      },
      ...prev
    ]);
  };

  // Excel Exporter simulation
  const handleExportCSV = () => {
    let csv = "Ticker,Holding Shares,Purchase Price ($),Current Price ($),Cost Basis ($),Market Value ($),Net Returns ($),Returns (%)\n";
    let totalInvest = 0;
    let totalVal = 0;

    portfolio.forEach((item) => {
      const live = liveStocks[item.ticker];
      const currentPrice = live ? live.price : item.purchasePrice;
      const costBasis = item.shares * item.purchasePrice;
      const marketVal = item.shares * currentPrice;
      const netReturns = marketVal - costBasis;
      const returnsPct = costBasis > 0 ? (netReturns / costBasis) * 100 : 0;
      
      totalInvest += costBasis;
      totalVal += marketVal;

      csv += `${item.ticker},${item.shares},${item.purchasePrice.toFixed(2)},${currentPrice.toFixed(2)},${costBasis.toFixed(2)},${marketVal.toFixed(2)},${netReturns.toFixed(2)},${returnsPct.toFixed(1)}\n`;
    });

    const net = totalVal - totalInvest;
    const netPct = totalInvest > 0 ? (net / totalInvest) * 100 : 0;
    csv += `TOTALS,-,-,-,${totalInvest.toFixed(2)},${totalVal.toFixed(2)},${net.toFixed(2)},${netPct.toFixed(1)}\n`;

    const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `portfolio_intelligence_returns_${new Date().toISOString().split("T")[0]}.csv`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Printable Summary text downloader simulation (PDF proxy)
  const handleExportTextSummary = () => {
    let report = `==========================================================\n`;
    report += `       AI PORTFOLIO INTELLIGENCE SYSTEM BRIEFING        \n`;
    report += `==========================================================\n`;
    report += `Report Date: ${new Date().toLocaleDateString()}\n`;
    report += `Client: ${username} (${email})\n\n`;

    let totalCost = 0;
    let totalValue = 0;

    report += `ACTIVE POSITIONS DETAIL:\n`;
    report += `----------------------------------------------------------\n`;
    report += `Ticker  | Shares  | Buy Price | Cur Price | Profit/Loss\n`;
    report += `----------------------------------------------------------\n`;

    portfolio.forEach((item) => {
      const live = liveStocks[item.ticker];
      const curPrice = live ? live.price : item.purchasePrice;
      const cost = item.shares * item.purchasePrice;
      const val = item.shares * curPrice;
      const pl = val - cost;
      
      totalCost += cost;
      totalValue += val;

      report += `${item.ticker.padEnd(7)} | ${item.shares.toString().padEnd(7)} | $${item.purchasePrice.toFixed(2).padEnd(9)} | $${curPrice.toFixed(2).padEnd(9)} | $${pl.toFixed(2)}\n`;
    });

    const overallPL = totalValue - totalCost;
    const overallPct = totalCost > 0 ? (overallPL / totalCost) * 100 : 0;

    report += `----------------------------------------------------------\n`;
    report += `TOTAL COST BASIS:   $${totalCost.toFixed(2)}\n`;
    report += `CURRENT VALUATION:  $${totalValue.toFixed(2)}\n`;
    report += `ABSOLUTE NET GAIN:  $${overallPL.toFixed(2)} (${overallPL >= 0 ? "+" : ""}${overallPct.toFixed(1)}%)\n`;
    report += `==========================================================\n`;
    report += `AI Recommendation Engine active. Configure process.env.GEMINI_API_KEY\n`;
    report += `to enable live LLM financial forecasting on our production code.\n`;

    const blob = new Blob([report], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `executive_briefing_returns_${new Date().toISOString().split("T")[0]}.txt`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Financial Calculations
  const calculateTotalCost = () => portfolio.reduce((acc, curr) => acc + curr.shares * curr.purchasePrice, 0);
  const calculateTotalVal = () => portfolio.reduce((acc, curr) => {
    const price = liveStocks[curr.ticker]?.price || curr.purchasePrice;
    return acc + curr.shares * price;
  }, 0);

  const totalCost = calculateTotalCost();
  const totalValue = calculateTotalVal();
  const netProfit = totalValue - totalCost;
  const netProfitPercent = totalCost > 0 ? (netProfit / totalCost) * 100 : 0;
  const isNetGain = netProfit >= 0;

  // Handle Login and registration submission
  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (username && password) {
      setIsAuthenticated(true);
    }
  };

  const handleRegisterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (username && email && password) {
      setIsAuthenticated(true);
    }
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-[#0A0B0E] flex flex-col justify-center py-12 sm:px-6 lg:px-8 font-sans text-slate-200">
        <div className="sm:mx-auto sm:w-full sm:max-w-md text-center">
          <div className="mx-auto h-12 w-12 rounded-2xl bg-indigo-600 flex items-center justify-center shadow-lg shadow-indigo-500/20">
            <Activity className="h-6 w-6 text-white" />
          </div>
          <h2 className="mt-6 text-3xl font-bold tracking-tight text-white">
            AI Portfolio Intelligence
          </h2>
          <p className="mt-2 text-xs text-slate-400">
            Machine Learning Trend Analysis & Institutional AI Advisor Desk
          </p>
        </div>

        <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md">
          <div className="bg-[#16181C] py-8 px-6 border border-slate-800 rounded-3xl sm:px-10 shadow-xl">
            <h3 className="text-xs font-bold tracking-wider text-slate-400 text-center mb-6 uppercase">
              {isRegistering ? "CREATE YOUR ADVISORY ACCOUNT" : "SIGN IN TO YOUR CO-PILOT TERMINAL"}
            </h3>

            {isRegistering ? (
              <form onSubmit={handleRegisterSubmit} className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">Username</label>
                  <input
                    type="text"
                    required
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    className="w-full rounded-xl border border-slate-800 px-4 py-3 bg-[#111418] text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">Email address</label>
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full rounded-xl border border-slate-800 px-4 py-3 bg-[#111418] text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">Password</label>
                  <input
                    type="password"
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full rounded-xl border border-slate-800 px-4 py-3 bg-[#111418] text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition"
                  />
                </div>
                <button
                  type="submit"
                  className="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-medium text-sm py-3 px-4 rounded-xl shadow-lg shadow-indigo-500/10 transition duration-200 flex items-center justify-center gap-2 cursor-pointer"
                >
                  Create Account
                </button>
              </form>
            ) : (
              <form onSubmit={handleLoginSubmit} className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">Username</label>
                  <input
                    type="text"
                    required
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    className="w-full rounded-xl border border-slate-800 px-4 py-3 bg-[#111418] text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">Password</label>
                  <input
                    type="password"
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full rounded-xl border border-slate-800 px-4 py-3 bg-[#111418] text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition"
                  />
                </div>
                <button
                  type="submit"
                  className="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-medium text-sm py-3 px-4 rounded-xl shadow-lg shadow-indigo-500/10 transition duration-200 flex items-center justify-center gap-2 cursor-pointer"
                >
                  Access Terminal
                </button>
              </form>
            )}

            <div className="mt-6 text-center text-xs">
              <button
                onClick={() => setIsRegistering(!isRegistering)}
                className="text-indigo-400 hover:text-indigo-300 font-semibold cursor-pointer"
              >
                {isRegistering ? "Already have an account? Sign In" : "Need an advisory workspace? Register account"}
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0A0B0E] text-slate-200 font-sans flex flex-col">
      {/* Top Header Controls bar */}
      <header className="bg-[#111418] border-b border-slate-800 py-3 px-6 sticky top-0 z-50 flex items-center justify-between shadow-md">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-indigo-600 flex items-center justify-center shadow-lg shadow-indigo-500/20">
            <Activity className="w-5 h-5 text-white" />
          </div>
          <div>
            <h1 className="text-sm font-bold text-white">AI Portfolio Intelligence System</h1>
            <span className="text-[10px] text-slate-500 font-semibold tracking-wider uppercase">Terminal Console v1.0.0</span>
          </div>
        </div>

        {/* Workspace Quick TABS Navigation */}
        <nav className="hidden lg:flex items-center gap-1.5 bg-slate-900/50 p-1 rounded-xl border border-slate-800">
          {[
            { key: "dashboard", label: "Dashboard", icon: PieChart },
            { key: "portfolio", label: "Holdings Desk", icon: DollarSign },
            { key: "advisor", label: "AI Advisor", icon: Sparkles },
            { key: "comparison", label: "Quant Compare", icon: TrendingUp },
            { key: "alerts", label: "Mail Alerts", icon: ShieldAlert },
            { key: "python", label: "Code Exporter", icon: Code }
          ].map((item) => {
            const Icon = item.icon;
            const isSelected = activeTab === item.key;
            return (
              <button
                key={item.key}
                onClick={() => setActiveTab(item.key as any)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition cursor-pointer border ${
                  isSelected
                    ? "bg-indigo-600/15 text-indigo-400 border-indigo-500/30"
                    : "text-slate-400 hover:text-white border-transparent"
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                {item.label}
              </button>
            );
          })}
        </nav>

        {/* User context & triggers */}
        <div className="flex items-center gap-4 text-xs">
          <div className="flex items-center gap-1">
            <button
              onClick={() => fetchStockPrices()}
              disabled={isRefreshing}
              className="p-1.5 rounded-lg border border-slate-800 hover:bg-slate-800 text-slate-400 flex items-center justify-center transition disabled:opacity-40 cursor-pointer"
              title="Poll quotes refresh"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? "animate-spin" : ""}`} />
            </button>
          </div>

          <div className="flex items-center gap-2 border-l border-slate-800 pl-4">
            <User className="w-4 h-4 text-slate-400" />
            <span className="font-semibold text-slate-200">{username}</span>
            <button
              onClick={() => setIsAuthenticated(false)}
              className="p-1.5 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 transition cursor-pointer"
              title="Lock terminal"
            >
              <LogOut className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </header>

      {/* Mobile view top select nav */}
      <div className="lg:hidden p-4 bg-[#111418] border-b border-slate-800">
        <select
          value={activeTab}
          onChange={(e) => setActiveTab(e.target.value as any)}
          className="w-full rounded-xl border border-slate-800 px-4 py-2.5 bg-[#16181C] text-slate-200 text-xs font-semibold focus:outline-none cursor-pointer"
        >
          <option value="dashboard">📊 Overview Dashboard</option>
          <option value="portfolio">💼 Portfolio Manager</option>
          <option value="advisor">🤖 AI advisory</option>
          <option value="comparison">⚡ Volatility & Comparison</option>
          <option value="alerts">✉️ SMTP alert watchers</option>
          <option value="python">📁 Python Streamlit Exporter</option>
        </select>
      </div>

      {/* Active Workspaces Wrapper */}
      <main className="flex-1 p-4 lg:p-8 max-w-7xl w-full mx-auto space-y-8">
        
        {/* Workspace Selector Routing */}
        {activeTab === "dashboard" && (
          <div className="space-y-8">
            <div className="flex flex-wrap items-center justify-between gap-4">
              <div>
                <h2 className="text-xl font-bold text-white">Strategic Performance Dashboard</h2>
                <p className="text-xs text-slate-400 mt-1">
                  Absolute capital returns, sector allocations, and technical risk indices.
                </p>
              </div>

              {portfolio.length > 0 && (
                <div className="flex items-center gap-2">
                  <button
                    onClick={handleExportCSV}
                    className="px-3.5 py-2 border border-slate-800 rounded-xl bg-[#16181C] text-xs font-semibold text-slate-300 hover:bg-slate-800 transition flex items-center gap-1.5 cursor-pointer"
                  >
                    <FileSpreadsheet className="w-4 h-4 text-emerald-400" />
                    Spreadsheet Report (.CSV)
                  </button>
                  <button
                    onClick={handleExportTextSummary}
                    className="px-3.5 py-2 border border-slate-800 rounded-xl bg-[#16181C] text-xs font-semibold text-slate-300 hover:bg-slate-800 transition flex items-center gap-1.5 cursor-pointer"
                  >
                    <FileText className="w-4 h-4 text-indigo-400" />
                    Executive Briefing (.TXT)
                  </button>
                </div>
              )}
            </div>

            {/* Overall counters overview */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
              <div className="bg-[#16181C] border border-slate-800 p-6 rounded-2xl shadow-lg flex items-start gap-4">
                <div className="w-10 h-10 rounded-xl bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center text-indigo-400 shrink-0">
                  <DollarSign className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">Investment Capital</span>
                  <span className="text-2xl font-bold text-white mt-1 block">
                    ${totalCost.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </span>
                </div>
              </div>

              <div className="bg-[#16181C] border border-slate-800 p-6 rounded-2xl shadow-lg flex items-start gap-4">
                <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400 shrink-0">
                  <Activity className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">Portfolio Valuation</span>
                  <span className="text-2xl font-bold text-white mt-1 block">
                    ${totalValue.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </span>
                </div>
              </div>

              <div className="bg-[#16181C] border border-slate-800 p-6 rounded-2xl shadow-lg flex items-start gap-4">
                <div className={`w-10 h-10 rounded-xl border shrink-0 flex items-center justify-center ${isNetGain ? "bg-emerald-500/10 border-emerald-500/20 text-emerald-400" : "bg-rose-500/10 border-rose-500/20 text-rose-400"}`}>
                  {isNetGain ? <TrendingUp className="w-5 h-5" /> : <TrendingDown className="w-5 h-5" />}
                </div>
                <div>
                  <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">Absolute Cumulative P/L</span>
                  <span className={`text-2xl font-bold mt-1 block ${isNetGain ? "text-emerald-400" : "text-rose-400"}`}>
                    {isNetGain ? "+" : ""}${netProfit.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    <span className="text-xs font-mono font-medium ml-1.5">
                      ({isNetGain ? "+" : ""}{netProfitPercent.toFixed(1)}%)
                    </span>
                  </span>
                </div>
              </div>
            </div>

            {/* Risk indicators component */}
            <RiskDashboard portfolio={portfolio} liveStocks={liveStocks} />
          </div>
        )}

        {activeTab === "portfolio" && (
          <div className="space-y-6">
            <div>
              <h2 className="text-xl font-bold text-white">Portfolio Transaction Registry</h2>
              <p className="text-xs text-slate-400 mt-1">
                Log and manage shares purchases. Commits to simulated MySQL persistence database rules.
              </p>
            </div>
            <PortfolioManager
              portfolio={portfolio}
              liveStocks={liveStocks}
              onAddPosition={handleAddPosition}
              onRemovePosition={handleRemovePosition}
            />
          </div>
        )}

        {activeTab === "advisor" && (
          <div className="space-y-6">
            <div>
              <h2 className="text-xl font-bold text-white">AI Advisor Co-Pilot Terminal</h2>
              <p className="text-xs text-slate-400 mt-1">
                Linear Regression ML Price Targets paired with secure server-side Gemini advisory summaries.
              </p>
            </div>
            <AIAdvisor portfolio={portfolio} liveStocks={liveStocks} history={history} />
          </div>
        )}

        {activeTab === "comparison" && (
          <div className="space-y-6">
            <div>
              <h2 className="text-xl font-bold text-white">Historical Normalized Analytics</h2>
              <p className="text-xs text-slate-400 mt-1">
                Trace and normalize performance curves of major equities to compare long term relative returns.
              </p>
            </div>
            <StockComparison liveStocks={liveStocks} history={history} />
          </div>
        )}

        {activeTab === "alerts" && (
          <div className="space-y-6">
            <div>
              <h2 className="text-xl font-bold text-white">SMTP Notification Dispatch</h2>
              <p className="text-xs text-slate-400 mt-1">
                Establish warning alert triggers and review simulated SMTP email dispatches in real-time.
              </p>
            </div>
            <AlertsSimulator
              liveStocks={liveStocks}
              notifications={notifications}
              rules={alertRules}
              onAddRule={handleAddRule}
              onRemoveRule={handleRemoveRule}
              onTriggerSimulatedNotification={handleTriggerSimulatedNotification}
            />
          </div>
        )}

        {activeTab === "python" && (
          <div className="space-y-6">
            <div>
              <h2 className="text-xl font-bold text-white">Python + MySQL Project Code Generator</h2>
              <p className="text-xs text-slate-400 mt-1">
                Review and download the complete, production-ready Streamlit source code and MySQL schema structures.
              </p>
            </div>
            <ProjectCodeExporter />
          </div>
        )}

      </main>

      <footer className="bg-[#111418] border-t border-slate-800 py-6 mt-16">
        <div className="max-w-7xl mx-auto px-6 text-center text-[11px] text-slate-500 space-y-1">
          <p>© 2026 AI Portfolio Intelligence System. Designed and compiled for premium institutional capital oversight.</p>
          <p>Local sandbox environment active on port 3000. All operations synced in local transaction registry.</p>
        </div>
      </footer>
    </div>
  );
}
