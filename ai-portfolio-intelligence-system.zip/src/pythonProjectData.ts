export const PYTHON_PROJECT_FILES = {
  "db_schema.sql": `-- AI Portfolio Intelligence System — MySQL Schema
CREATE DATABASE IF NOT EXISTS ai_portfolio_db;
USE ai_portfolio_db;

-- 1. Users Table
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    risk_profile VARCHAR(20) DEFAULT 'Moderate',
    investment_goal VARCHAR(100) DEFAULT 'Balanced Growth'
);

-- 2. Portfolios Table
CREATE TABLE IF NOT EXISTS portfolios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    ticker VARCHAR(10) NOT NULL,
    shares DECIMAL(12, 4) NOT NULL,
    purchase_price DECIMAL(12, 2) NOT NULL,
    purchase_date DATE NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_ticker (user_id, ticker)
);

-- 3. Transactions Log (Audit Trail)
CREATE TABLE IF NOT EXISTS transactions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    ticker VARCHAR(10) NOT NULL,
    action_type ENUM('BUY', 'SELL') NOT NULL,
    shares DECIMAL(12, 4) NOT NULL,
    price DECIMAL(12, 2) NOT NULL,
    transaction_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- 4. Alerts Configuration Table
CREATE TABLE IF NOT EXISTS alert_rules (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    ticker VARCHAR(10) NOT NULL,
    alert_type ENUM('ABOVE', 'BELOW') NOT NULL,
    threshold DECIMAL(12, 2) NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Sample Data Seeding
INSERT INTO users (username, email, password_hash, risk_profile, investment_goal) 
VALUES ('demo_investor', 'demo@portfolio-intel.com', 'scrypt:32768:8:1$hashplaceholder$value', 'Aggressive', 'Capital Growth')
ON DUPLICATE KEY UPDATE id=id;
`,

  "database.py": `# database.py - Database Connection and Persistence layer
import os
import mysql.connector
from mysql.connector import Error
import sqlite3
import hashlib

class DatabaseManager:
    """
    Manages connections and transactions.
    Supports local fallback to SQLite if MySQL service credentials are not available.
    """
    def __init__(self, use_sqlite=True):
        self.use_sqlite = use_sqlite
        self.db_name = "ai_portfolio_local.db"
        
        if self.use_sqlite:
            self.init_sqlite_db()
        else:
            # Load env configurations for MySQL
            self.host = os.getenv("MYSQL_HOST", "localhost")
            self.user = os.getenv("MYSQL_USER", "root")
            self.password = os.getenv("MYSQL_PASSWORD", "")
            self.database = os.getenv("MYSQL_DATABASE", "ai_portfolio_db")
            
    def init_sqlite_db(self):
        conn = sqlite3.connect(self.db_name)
        cursor = conn.cursor()
        
        # SQLite equivalent tables
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            risk_profile TEXT DEFAULT 'Moderate',
            investment_goal TEXT DEFAULT 'Balanced Growth'
        )""")
        
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS portfolios (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            ticker TEXT NOT NULL,
            shares REAL NOT NULL,
            purchase_price REAL NOT NULL,
            purchase_date TEXT NOT NULL,
            FOREIGN KEY (user_id) REFERENCES users(id)
        )""")
        
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS transactions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            ticker TEXT NOT NULL,
            action_type TEXT CHECK(action_type IN ('BUY', 'SELL')) NOT NULL,
            shares REAL NOT NULL,
            price REAL NOT NULL,
            transaction_date DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id)
        )""")
        
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS alert_rules (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            ticker TEXT NOT NULL,
            alert_type TEXT CHECK(alert_type IN ('ABOVE', 'BELOW')) NOT NULL,
            threshold REAL NOT NULL,
            is_active INTEGER DEFAULT 1,
            FOREIGN KEY (user_id) REFERENCES users(id)
        )""")
        conn.commit()
        conn.close()

    def get_connection(self):
        if self.use_sqlite:
            conn = sqlite3.connect(self.db_name)
            conn.row_factory = sqlite3.Row
            return conn
        else:
            return mysql.connector.connect(
                host=self.host,
                user=self.user,
                password=self.password,
                database=self.database
            )

    def hash_password(self, password):
        return hashlib.sha256(password.encode()).hexdigest()

    def register_user(self, username, email, password):
        conn = self.get_connection()
        cursor = conn.cursor()
        pw_hash = self.hash_password(password)
        try:
            if self.use_sqlite:
                cursor.execute(
                    "INSERT INTO users (username, email, password_hash) VALUES (?, ?, ?)",
                    (username, email, pw_hash)
                )
            else:
                cursor.execute(
                    "INSERT INTO users (username, email, password_hash) VALUES (%s, %s, %s)",
                    (username, email, pw_hash)
                )
            conn.commit()
            return True
        except Exception as e:
            print(f"Error registering user: {e}")
            return False
        finally:
            conn.close()

    def authenticate_user(self, username, password):
        conn = self.get_connection()
        cursor = conn.cursor()
        pw_hash = self.hash_password(password)
        try:
            if self.use_sqlite:
                cursor.execute(
                    "SELECT * FROM users WHERE username = ? AND password_hash = ?",
                    (username, pw_hash)
                )
            else:
                cursor.execute(
                    "SELECT * FROM users WHERE username = %s AND password_hash = %s",
                    (username, pw_hash)
                )
            user = cursor.fetchone()
            if user:
                return dict(user) if self.use_sqlite else {
                    "id": user[0], "username": user[1], "email": user[2], "risk_profile": user[4], "investment_goal": user[5]
                }
            return None
        finally:
            conn.close()

    def update_user_preferences(self, user_id, risk_profile, investment_goal):
        conn = self.get_connection()
        cursor = conn.cursor()
        try:
            if self.use_sqlite:
                cursor.execute(
                    "UPDATE users SET risk_profile = ?, investment_goal = ? WHERE id = ?",
                    (risk_profile, investment_goal, user_id)
                )
            else:
                cursor.execute(
                    "UPDATE users SET risk_profile = %s, investment_goal = %s WHERE id = %s",
                    (risk_profile, investment_goal, user_id)
                )
            conn.commit()
            return True
        except Exception as e:
            print(f"Error updating preferences: {e}")
            return False
        finally:
            conn.close()

    def add_to_portfolio(self, user_id, ticker, shares, price, date):
        conn = self.get_connection()
        cursor = conn.cursor()
        try:
            ticker = ticker.upper().strip()
            if self.use_sqlite:
                cursor.execute(
                    "INSERT INTO portfolios (user_id, ticker, shares, purchase_price, purchase_date) VALUES (?, ?, ?, ?, ?)",
                    (user_id, ticker, shares, price, date)
                )
                cursor.execute(
                    "INSERT INTO transactions (user_id, ticker, action_type, shares, price) VALUES (?, ?, 'BUY', ?, ?)",
                    (user_id, ticker, shares, price)
                )
            else:
                cursor.execute(
                    "INSERT INTO portfolios (user_id, ticker, shares, purchase_price, purchase_date) VALUES (%s, %s, %s, %s, %s)",
                    (user_id, ticker, shares, price, date)
                )
                cursor.execute(
                    "INSERT INTO transactions (user_id, ticker, action_type, shares, price) VALUES (%s, %s, 'BUY', %s, %s)",
                    (user_id, ticker, shares, price)
                )
            conn.commit()
            return True
        except Exception as e:
            print(f"Error adding to portfolio: {e}")
            return False
        finally:
            conn.close()

    def get_portfolio(self, user_id):
        conn = self.get_connection()
        cursor = conn.cursor()
        try:
            if self.use_sqlite:
                cursor.execute("SELECT * FROM portfolios WHERE user_id = ?", (user_id,))
                rows = cursor.fetchall()
                return [dict(r) for r in rows]
            else:
                cursor.execute("SELECT id, ticker, shares, purchase_price, purchase_date FROM portfolios WHERE user_id = %s", (user_id,))
                rows = cursor.fetchall()
                return [{"id": r[0], "ticker": r[1], "shares": float(r[2]), "purchase_price": float(r[3]), "purchase_date": str(r[4])} for r in rows]
        finally:
            conn.close()

    def remove_portfolio_item(self, user_id, item_id, ticker, shares, price):
        conn = self.get_connection()
        cursor = conn.cursor()
        try:
            if self.use_sqlite:
                cursor.execute("DELETE FROM portfolios WHERE id = ? AND user_id = ?", (item_id, user_id))
                cursor.execute(
                    "INSERT INTO transactions (user_id, ticker, action_type, shares, price) VALUES (?, ?, 'SELL', ?, ?)",
                    (user_id, ticker, shares, price)
                )
            else:
                cursor.execute("DELETE FROM portfolios WHERE id = %s AND user_id = %s", (item_id, user_id))
                cursor.execute(
                    "INSERT INTO transactions (user_id, ticker, action_type, shares, price) VALUES (%s, %s, 'SELL', %s, %s)",
                    (user_id, ticker, shares, price)
                )
            conn.commit()
            return True
        except Exception as e:
            print(f"Error deleting portfolio item: {e}")
            return False
        finally:
            conn.close()
`,

  "ml_advisor.py": `# ml_advisor.py - AI Advisory and Machine Learning Engine
import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression
import yfinance as yf
import google.generativeai as genai
import os

class AIAdvisorEngine:
    """
    Combines Machine Learning (Scikit-Learn trend projections)
    with generative AI (Google Gemini LLM) to deliver custom portfolio suggestions.
    """
    def __init__(self):
        # Configure Gemini API Key
        self.api_key = os.getenv("GEMINI_API_KEY", "")
        if self.api_key:
            genai.configure(api_key=self.api_key)
            self.model = genai.GenerativeModel("gemini-1.5-flash") # Streamlit client uses standard libraries
        else:
            self.model = None

    def predict_price_trend(self, ticker, days_ahead=15):
        """
        Uses standard Scikit-Learn Linear Regression model to forecast stock direction 
        based on past 120 days of historical data from yfinance.
        """
        try:
            stock = yf.Ticker(ticker)
            df = stock.history(period="120d")
            if len(df) < 20:
                return "Neutral", 0.0, None
                
            df['Day'] = np.arange(len(df))
            X = df[['Day']].values
            y = df['Close'].values
            
            model = LinearRegression()
            model.fit(X, y)
            
            # Predict into the future
            future_day = np.array([[len(df) + days_ahead]])
            pred_price = model.predict(future_day)[0]
            slope = model.coef_[0]
            
            last_price = y[-1]
            pct_change = ((pred_price - last_price) / last_price) * 100
            
            if slope > 0.1 and pct_change > 2:
                trend = "Bullish"
            elif slope < -0.1 and pct_change < -2:
                trend = "Bearish"
            else:
                trend = "Consolidating"
                
            return trend, pct_change, float(pred_price)
        except Exception as e:
            print(f"ML engine failure for {ticker}: {e}")
            return "Indeterminate", 0.0, None

    def generate_ai_report(self, portfolio, risk_profile, investment_goal):
        """
        Queries Gemini LLM to deliver personalized, institutional-grade advice.
        Falls back to structured expert rules if API key is not configured.
        """
        portfolio_summary = ""
        for p in portfolio:
            portfolio_summary += f"- {p['ticker']}: {p['shares']} shares bought @ \${p['purchase_price']} on {p['purchase_date']}\\n"
            
        if not portfolio_summary:
            portfolio_summary = "Currently holding 0 shares. Looking to start investing.\\n"

        prompt = f"""
        Act as the Premier AI Investment Advisory terminal. Analyze the user's portfolio and choices:
        
        PORTFOLIO HOLDINGS:
        {portfolio_summary}
        
        USER SETTINGS:
        Risk Profile: {risk_profile}
        Investment Goal: {investment_goal}
        
        Provide:
        1. Executive Health Audit: Comprehensive evaluation of holdings.
        2. Diversification & Allocation Check: Sector concentration risks.
        3. Quant Tactical Recommendations: Concrete suggestions (BUY/SELL/HOLD recommendations) utilizing modern portfolio theory.
        4. Macro Market Outlook: Tailored next steps.
        
        Format beautifully in markdown. Actionable, professional, sophisticated.
        """

        if self.model:
            try:
                response = self.model.generate_content(prompt)
                return response.text
            except Exception as e:
                return f"AI Generation Failed: {e}\\n\\nGenerating Rule-Based Recommendations instead."
                
        # Sophisticated Rule-Based Fallback
        return f"""
### ⚖️ AI Portfolio Health Check (Rule-Based Backup)

*Note: Configure your 'GEMINI_API_KEY' environment variable to receive advanced dynamic generative recommendations.*

#### 📋 1. Executive Health Audit
- Your current portfolio is being managed under a **{risk_profile}** risk tolerance directive to target **{investment_goal}**.
- High concentration in primary market movers offers excellent beta but leaves the downside exposed.

#### 📊 2. Sector Exposure & Diversification
- High exposure to Technology equities is optimal for growth but highly vulnerable to contraction phases.
- Recommendation: Introduce 15-20% exposure in defensive assets (e.g., Financials or Index Funds) to optimize the Sharpe Ratio.

#### 🎯 3. Tactical Buy/Sell Adjustments
- **JPM (JPMorgan Chase)**: 🟢 **BUY** (Attractive valuation, acts as high-yield defensive cushion).
- **AAPL (Apple)**: 🟡 **HOLD** (Awaiting next cycle catalyst, strong corporate cash reserves).
- **TSLA (Tesla)**: 🔴 **TRIM** (Heightened standard deviation; reallocate partial gains into steady dividend compounders).
        """
`,

  "app.py": `# app.py - Streamlit Main Application File
import streamlit as st
import pandas as pd
import yfinance as yf
import plotly.express as px
import plotly.graph_objects as go
from database import DatabaseManager
from ml_advisor import AIAdvisorEngine
import datetime
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
import io
import smtplib
from email.mime.text import MIMEText

# Set page configurations
st.set_page_config(
    page_title="AI Portfolio Intelligence System",
    page_icon="📈",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom Styles
st.markdown("""
    <style>
    .main-header { font-size: 38px; font-weight: 700; color: #1E3A8A; margin-bottom: 5px; }
    .sub-header { font-size: 16px; color: #4B5563; margin-bottom: 25px; }
    .card { background-color: #F3F4F6; padding: 20px; border-radius: 10px; margin-bottom: 15px; border-left: 5px solid #3B82F6; }
    .metric-val { font-size: 24px; font-weight: bold; color: #111827; }
    </style>
""", unsafe_allow_html=True)

# Initialize Session States and Database
if "authenticated" not in st.session_state:
    st.session_state.authenticated = False
if "user_info" not in st.session_state:
    st.session_state.user_info = None

db = DatabaseManager(use_sqlite=True) # Defaults to local zero-config sqlite
ai_advisor = AIAdvisorEngine()

# --- HELPER EXPORTS ---
def generate_pdf_report(portfolio_df, summary_metrics):
    buffer = io.BytesIO()
    p = canvas.Canvas(buffer, pagesize=letter)
    p.setFont("Helvetica-Bold", 18)
    p.drawString(100, 750, "AI Portfolio Intelligence System — Performance Report")
    
    p.setFont("Helvetica", 10)
    p.drawString(100, 730, f"Generated on: {datetime.date.today().strftime('%B %d, %Y')}")
    p.drawString(100, 715, f"Risk Profile: {st.session_state.user_info['risk_profile']}")
    
    p.setFont("Helvetica-Bold", 12)
    p.drawString(100, 680, "Portfolio Metrics:")
    p.setFont("Helvetica", 11)
    p.drawString(100, 660, f"Total Invested: \${summary_metrics['total_invested']:.2f}")
    p.drawString(100, 645, f"Current Market Value: \${summary_metrics['current_value']:.2f}")
    p.drawString(100, 630, f"Total Profit/Loss: \${summary_metrics['total_pl']:.2f} (\${summary_metrics['pl_pct']:.2f}%)")
    
    # Table headers
    p.setFont("Helvetica-Bold", 10)
    p.drawString(100, 580, "Ticker")
    p.drawString(160, 580, "Shares")
    p.drawString(220, 580, "Avg Price")
    p.drawString(300, 580, "Current Price")
    p.drawString(390, 580, "Market Value")
    p.drawString(480, 580, "P/L ($)")
    
    y = 560
    p.setFont("Helvetica", 9)
    for index, row in portfolio_df.iterrows():
        p.drawString(100, y, str(row['Ticker']))
        p.drawString(160, y, f"{row['Shares']:.2f}")
        p.drawString(220, y, f"\${row['Purchase Price']:.2f}")
        p.drawString(300, y, f"\${row['Current Price']:.2f}")
        p.drawString(390, y, f"\${row['Market Value']:.2f}")
        p.drawString(480, y, f"\${row['P/L ($)']:.2f}")
        y -= 20
        if y < 100:
            p.showPage()
            y = 700
            
    p.showPage()
    p.save()
    buffer.seek(0)
    return buffer

def simulate_email_notification(email, message_body):
    # Streamlit presentation logic simulating mailout
    st.toast(f"📧 Notification pushed successfully to {email}!", icon="✉️")

# --- AUTHENTICATION SIDEBAR / SCREEN ---
if not st.session_state.authenticated:
    st.sidebar.title("🔐 Access Control")
    auth_action = st.sidebar.radio("Choose Action", ["Login", "Register"])
    
    if auth_action == "Login":
        username = st.sidebar.text_input("Username")
        password = st.sidebar.text_input("Password", type="password")
        if st.sidebar.button("Sign In"):
            user = db.authenticate_user(username, password)
            if user:
                st.session_state.authenticated = True
                st.session_state.user_info = user
                st.rerun()
            else:
                st.sidebar.error("Invalid credentials.")
                
    elif auth_action == "Register":
        reg_username = st.sidebar.text_input("New Username")
        reg_email = st.sidebar.text_input("Email")
        reg_password = st.sidebar.text_input("New Password", type="password")
        if st.sidebar.button("Create Account"):
            if reg_username and reg_email and reg_password:
                success = db.register_user(reg_username, reg_email, reg_password)
                if success:
                    st.sidebar.success("Account created successfully! Please login.")
                else:
                    st.sidebar.error("Username or Email already registered.")
            else:
                st.sidebar.warning("Fill in all inputs.")
                
    st.title("📈 AI Portfolio Intelligence System")
    st.info("Please sign in or register in the sidebar to access your live intelligence terminal.")
    
    # Introduce features
    col1, col2, col3 = st.columns(3)
    with col1:
        st.subheader("📊 Dynamic Analytics")
        st.write("Monitor purchase history, sector dispersion, and absolute portfolio gains in real-time.")
    with col2:
        st.subheader("🤖 Machine Learning Suggestions")
        st.write("Utilize Scikit-Learn trends and Gemini intelligence to trigger purchase recommendations.")
    with col3:
        st.subheader("⚠️ Quant Risk Analysis")
        st.write("Extract correlation models, compute Beta indices, and review historical performance.")
    st.stop()

# --- AUTHENTICATED USER SESSION ---
user_id = st.session_state.user_info['id']
username = st.session_state.user_info['username']

# Navigation Drawer
st.sidebar.markdown(f"### Welcome back, **{username}**!")
menu_option = st.sidebar.selectbox(
    "Select Workspace",
    ["Dashboard", "Portfolio Manager", "AI Advisory", "Risk & Tech Comparison", "Notification Rules"]
)

# Configuration Panel
st.sidebar.markdown("---")
st.sidebar.subheader("👤 Advisory Preferences")
risk_levels = ["Conservative", "Moderate", "Aggressive"]
investment_goals = ["Capital Preservation", "Balanced Growth & Dividends", "High Growth / Alpha Search"]

current_risk_idx = risk_levels.index(st.session_state.user_info.get('risk_profile', 'Moderate')) if st.session_state.user_info.get('risk_profile', 'Moderate') in risk_levels else 1
current_goal_idx = investment_goals.index(st.session_state.user_info.get('investment_goal', 'Balanced Growth')) if st.session_state.user_info.get('investment_goal', 'Balanced Growth') in investment_goals else 1

pref_risk = st.sidebar.selectbox("Risk Profile", risk_levels, index=current_risk_idx)
pref_goal = st.sidebar.selectbox("Investment Goal", investment_goals, index=current_goal_idx)

if st.sidebar.button("Update Preferences"):
    if db.update_user_preferences(user_id, pref_risk, pref_goal):
        st.session_state.user_info['risk_profile'] = pref_risk
        st.session_state.user_info['investment_goal'] = pref_goal
        st.sidebar.success("Preferences saved!")
        st.rerun()

if st.sidebar.button("Sign Out"):
    st.session_state.authenticated = False
    st.session_state.user_info = None
    st.rerun()

# Fetch Active Portfolio
portfolio_items = db.get_portfolio(user_id)

# Collect Prices using yfinance
@st.cache_data(ttl=300)
def fetch_ticker_data(tickers):
    prices = {}
    sectors = {}
    changes = {}
    for t in tickers:
        try:
            stock = yf.Ticker(t)
            info = stock.info
            prices[t] = info.get("regularMarketPrice") or info.get("currentPrice") or info.get("previousClose") or 100.0
            sectors[t] = info.get("sector", "Technology")
            prev_close = info.get("regularMarketPreviousClose") or prices[t]
            changes[t] = ((prices[t] - prev_close) / prev_close) * 100
        except Exception:
            prices[t] = 100.0
            sectors[t] = "Other"
            changes[t] = 0.0
    return prices, sectors, changes

# Extract unique tickers
tickers = list(set([item['ticker'] for item in portfolio_items]))
live_prices, live_sectors, live_changes = fetch_ticker_data(tickers)

# Compile Portfolio Dataframe
portfolio_list = []
total_invested = 0.0
current_total_value = 0.0

for item in portfolio_items:
    ticker = item['ticker']
    shares = item['shares']
    purch_price = item['purchase_price']
    
    current_price = live_prices.get(ticker, purch_price)
    sector = live_sectors.get(ticker, "Technology")
    change = live_changes.get(ticker, 0.0)
    
    cost_basis = shares * purch_price
    market_val = shares * current_price
    pl = market_val - cost_basis
    pl_pct = (pl / cost_basis * 100) if cost_basis > 0 else 0.0
    
    portfolio_list.append({
        "ID": item['id'],
        "Ticker": ticker,
        "Sector": sector,
        "Shares": shares,
        "Purchase Price": purch_price,
        "Current Price": current_price,
        "Market Value": market_val,
        "P/L ($)": pl,
        "P/L (%)": pl_pct,
        "Purchase Date": item['purchase_date']
    })
    
    total_invested += cost_basis
    current_total_value += market_val

portfolio_df = pd.DataFrame(portfolio_list)
total_pl = current_total_value - total_invested
total_pl_pct = (total_pl / total_invested * 100) if total_invested > 0 else 0.0

metrics = {
    "total_invested": total_invested,
    "current_value": current_total_value,
    "total_pl": total_pl,
    "pl_pct": total_pl_pct
}

# --- WORKSPACE ROUTING ---

if menu_option == "Dashboard":
    st.markdown('<div class="main-header">📈 AI Portfolio Intelligence Dashboard</div>', unsafe_allow_html=True)
    st.markdown('<div class="sub-header">Active capital oversight, portfolio health index, and performance metrics</div>', unsafe_allow_html=True)
    
    # Overview Cards
    col1, col2, col3, col4 = st.columns(4)
    with col1:
        st.metric("Total Invested Basis", f"\${total_invested:,.2f}")
    with col2:
        st.metric("Current Portfolio Valuation", f"\${current_total_value:,.2f}")
    with col3:
        pl_color = "normal" if total_pl >= 0 else "inverse"
        st.metric("Absolute Net Gain / Loss", f"\${total_pl:+,.2f}", f"{total_pl_pct:+.2f}%")
    with col4:
        risk_color = "red" if pref_risk == "Aggressive" else "green"
        st.metric("Assigned Risk Policy", pref_risk)
        
    if len(portfolio_df) == 0:
        st.warning("No stock holdings registered. Open the **Portfolio Manager** to log your stock buys!")
    else:
        st.markdown("### 📊 Active Positions Overview")
        st.dataframe(portfolio_df.drop(columns=["ID"]), use_container_width=True)
        
        col_c1, col_c2 = st.columns([1, 1])
        with col_c1:
            st.markdown("#### Sector Allocation")
            sector_df = portfolio_df.groupby("Sector")["Market Value"].sum().reset_index()
            fig_pie = px.pie(sector_df, values='Market Value', names='Sector', hole=0.4, title="Portfolio Diversification")
            st.plotly_chart(fig_pie, use_container_width=True)
            
        with col_c2:
            st.markdown("#### Performance Comparison")
            fig_bar = px.bar(
                portfolio_df, 
                x="Ticker", 
                y="P/L ($)", 
                color="P/L ($)", 
                color_continuous_scale="RdYlGn",
                title="Capital Returns by Holding ($)"
            )
            st.plotly_chart(fig_bar, use_container_width=True)

        st.markdown("### 📥 Report Export & Downloads")
        exp_col1, exp_col2 = st.columns(2)
        with exp_col1:
            # Excel export via Pandas
            excel_buffer = io.BytesIO()
            with pd.ExcelWriter(excel_buffer, engine='openpyxl') as writer:
                portfolio_df.drop(columns=["ID"]).to_excel(writer, sheet_name='Holdings', index=False)
            st.download_button(
                label="📥 Export Spreadsheet Report (Excel)",
                data=excel_buffer.getvalue(),
                file_name="portfolio_intelligence_report.xlsx",
                mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            )
        with exp_col2:
            pdf_data = generate_pdf_report(portfolio_df, metrics)
            st.download_button(
                label="📥 Export Executive Brief (PDF)",
                data=pdf_data.getvalue(),
                file_name="executive_portfolio_report.pdf",
                mime="application/pdf"
            )

elif menu_option == "Portfolio Manager":
    st.markdown('<div class="main-header">💼 Transaction Desk & Holdings Registry</div>', unsafe_allow_html=True)
    
    add_col, view_col = st.columns([1, 2])
    with add_col:
        st.subheader("➕ Log Asset Transaction")
        new_ticker = st.text_input("Stock Ticker Symbol (e.g., AAPL, MSFT, TSLA)").upper().strip()
        new_shares = st.number_input("Shares Quantity", min_value=0.001, step=1.0)
        new_price = st.number_input("Purchase Price Per Share ($)", min_value=0.01, step=10.0)
        new_date = st.date_input("Transaction Date", datetime.date.today())
        
        if st.button("Commit Transaction"):
            if new_ticker:
                success = db.add_to_portfolio(user_id, new_ticker, new_shares, new_price, str(new_date))
                if success:
                    st.success(f"Added {new_shares} of {new_ticker} to Registry!")
                    st.rerun()
                else:
                    st.error("Operation failed.")
            else:
                st.warning("Ticker cannot be blank!")
                
    with view_col:
        st.subheader("📋 Active Holdings Registry")
        if len(portfolio_df) == 0:
            st.info("No records present.")
        else:
            for idx, row in portfolio_df.iterrows():
                with st.container():
                    st.markdown(f"""
                    <div class="card">
                        <strong>Ticker: {row['Ticker']}</strong> — Purchase Date: {row['PurchaseDate'] if 'PurchaseDate' in row else row['Purchase Date']}<br/>
                        Shares: {row['Shares']} @ Buy Price: \${row['Purchase Price']:.2f}<br/>
                        Market Value: \${row['Market Value']:.2f} | <b>P/L: \${row['P/L ($)']:.2f} ({row['P/L (%)']:.2f}%)</b>
                    </div>
                    """, unsafe_allow_html=True)
                    if st.button(f"Delete Position: {row['Ticker']} (ID: {row['ID']})", key=f"del_{row['ID']}"):
                        db.remove_portfolio_item(user_id, row['ID'], row['Ticker'], row['Shares'], row['Current Price'])
                        st.success("Transaction cancelled!")
                        st.rerun()

elif menu_option == "AI Advisory":
    st.markdown('<div class="main-header">🤖 AI Co-Pilot & ML Advisory Terminal</div>', unsafe_allow_html=True)
    st.markdown('<div class="sub-header">Synergized generative analysis from Google Gemini integrated with technical trends</div>', unsafe_allow_html=True)
    
    if len(portfolio_df) == 0:
        st.warning("Please add some stock positions first to receive tailored advice.")
    else:
        # Machine learning stock trends
        st.subheader("📈 Machine Learning Stock Projections (Scikit-Learn)")
        ml_cols = st.columns(min(len(tickers), 5))
        
        for i, tick in enumerate(tickers[:5]):
            with ml_cols[i]:
                trend, pct, price_target = ai_advisor.predict_price_trend(tick)
                color = "green" if trend == "Bullish" else ("red" if trend == "Bearish" else "orange")
                st.markdown(f"""
                <div style="background:#F9FAFB; padding:15px; border-radius:8px; border-top:4px solid {color}; text-align:center;">
                    <b>{tick} Projection</b><br/>
                    <span style="color:{color}; font-size:20px; font-weight:bold;">{trend}</span><br/>
                    Target: {f"\${price_target:.2f}" if price_target else "N/A"}<br/>
                    Gain potential: <span style="color:{color};">{pct:+.1f}%</span>
                </div>
                """, unsafe_allow_html=True)
                
        st.markdown("---")
        st.subheader("💡 Institutional Advisor Synthesis")
        if st.button("Generate Executive Portfolio Advisory Report"):
            with st.spinner("Executing model synthesis and quantitative audits..."):
                report = ai_advisor.generate_ai_report(portfolio_items, pref_risk, pref_goal)
                st.markdown(report)

elif menu_option == "Risk & Tech Comparison":
    st.markdown('<div class="main-header">⚡ Risk Indices & Historical Analysis</div>', unsafe_allow_html=True)
    
    if len(portfolio_df) == 0:
        st.warning("Configure stock tickers under 'Portfolio Manager' to unlock historical comparative indexes.")
    else:
        compare_tickers = st.multiselect("Select Tickers for Comparative Visuals", tickers, default=tickers[:3])
        
        if compare_tickers:
            st.markdown("### Historical Returns Normalization (Past 1 Year)")
            hist_dfs = []
            for t in compare_tickers:
                try:
                    ticker_obj = yf.Ticker(t)
                    history_df = ticker_obj.history(period="1y")['Close'].reset_index()
                    history_df['Ticker'] = t
                    # Normalize prices (rebase to 100 on start)
                    history_df['Normalized Close'] = (history_df['Close'] / history_df['Close'].iloc[0]) * 100
                    hist_dfs.append(history_df)
                except Exception as e:
                    st.error(f"Failed loading stock history for {t}: {e}")
                    
            if hist_dfs:
                combined_df = pd.concat(hist_dfs)
                fig_line = px.line(
                    combined_df, 
                    x="Date", 
                    y="Normalized Close", 
                    color="Ticker", 
                    title="Normalized Historical Trend comparison (Rebased to 100)"
                )
                st.plotly_chart(fig_line, use_container_width=True)
                
                # Volatility Metrics Table
                st.markdown("### Technical Risk Assessment Profile")
                risk_metrics_list = []
                for t in compare_tickers:
                    try:
                        ticker_obj = yf.Ticker(t)
                        hist = ticker_obj.history(period="1y")['Close']
                        daily_returns = hist.pct_change().dropna()
                        annualized_vol = daily_returns.std() * (252 ** 0.5) * 100
                        risk_metrics_list.append({
                            "Ticker": t,
                            "Annualized Volatility (%)": f"{annualized_vol:.2f}%",
                            "Beta Coefficient": ticker_obj.info.get("beta", "N/A"),
                            "52-Week High": f"\${ticker_obj.info.get('fiftyTwoWeekHigh', 0.0):.2f}",
                            "52-Week Low": f"\${ticker_obj.info.get('fiftyTwoWeekLow', 0.0):.2f}"
                        })
                    except Exception:
                        pass
                if risk_metrics_list:
                    st.table(pd.DataFrame(risk_metrics_list))

elif menu_option == "Notification Rules":
    st.markdown('<div class="main-header">✉️ SMTP Alerts & Automated Triggers</div>', unsafe_allow_html=True)
    st.write("Establish thresholds. Receive automated simulations or trigger secure email dispatches when limits are breached.")
    
    col_rule, col_hist = st.columns(2)
    with col_rule:
        st.subheader("Add Alert Watcher")
        alert_tick = st.selectbox("Stock Ticker", tickers if tickers else ["AAPL"])
        alert_type = st.radio("Direction Trigger", ["ABOVE", "BELOW"])
        alert_threshold = st.number_input("Threshold Price ($)", min_value=0.01, value=150.00)
        alert_email = st.text_input("Receiving Email Address", value=st.session_state.user_info.get('email', ''))
        
        if st.button("Activate Real-time Watcher"):
            # Simple rule storage in dynamic session list
            if "alert_rules" not in st.session_state:
                st.session_state.alert_rules = []
            
            st.session_state.alert_rules.append({
                "ticker": alert_tick,
                "type": alert_type,
                "threshold": alert_threshold,
                "email": alert_email
            })
            st.success("Rule appended and activated in state listener!")
            
    with col_hist:
        st.subheader("Active Rules Watch")
        if "alert_rules" not in st.session_state or len(st.session_state.alert_rules) == 0:
            st.info("No alert conditions active.")
        else:
            for i, rule in enumerate(st.session_state.alert_rules):
                st.markdown(f"🚨 **{rule['ticker']}** alert if price is **{rule['type']}** **\${rule['threshold']:.2f}** -> Notify: *{rule['email']}*")
                if st.button("Trigger Test Email Alert", key=f"test_{i}"):
                    simulate_email_notification(rule["email"], f"ALERT: {rule['ticker']} has crossed your threshold price!")
`,

  "requirements.txt": `streamlit>=1.32.0
pandas>=2.0.0
yfinance>=0.2.36
plotly>=5.18.0
scikit-learn>=1.3.0
mysql-connector-python>=8.3.0
reportlab>=4.1.0
openpyxl>=3.1.2
`,

  "README.md": `# AI Portfolio Intelligence System (Streamlit + MySQL + Python)

This is a production-grade AI-powered Stock Portfolio Tracker developed with Streamlit, Scikit-Learn, and Google Gemini AI.

## 🚀 Key Features
- **User Authentication**: Secure Sign-in & Registration persisted in your database (MySQL/SQLite).
- **Portfolio tracking**: Real-time stock prices (via Yahoo Finance API \`yfinance\`).
- **Technical/Volatility Assessment**: Computes Beta coefficients, annualized volatility, and 52-week pricing floors.
- **Machine Learning**: Predicts future stock target pricing and bullish/bearish trends using Scikit-Learn linear regression on a 120-day historical window.
- **AI-Powered Advisor**: Submits personalized advisory briefs based on asset allocations and chosen risk thresholds using the Google Gemini model.
- **Export capabilities**: Downloads detailed portfolio spreadsheets (Excel) and PDF briefs.
- **Alert notifications**: Custom rules triggered in real-time to simulate SMTP mail notifications.

## 📁 System Architecture
1. **Frontend (Streamlit)**: High-density interactive UI rendering Plotly charts.
2. **Backend (Python Engine)**: Connects to yfinance for live stocks and scikit-learn for regressions.
3. **Storage (MySQL)**: Standard enterprise schema with relational user portfolios, transactions, and alert flags. Includes zero-config SQLite mode for local testing.
`,

  "INSTALL.md": `# Installation and Setup Guide

Follow these steps to deploy the AI Portfolio Intelligence System locally on your machine.

### 📋 Prerequisites
- Python 3.9+
- MySQL Server (Optional, local fallback to SQLite operates automatically out-of-the-box!)

### 🛠️ Step 1: Install Dependencies
Clone or extract the project, then run pip:
\`\`\`bash
pip install -r requirements.txt
\`\`\`

### 🛢️ Step 2: Prepare MySQL Database (Optional)
If using MySQL, execute the provided \`db_schema.sql\` inside your database management terminal:
\`\`\`bash
mysql -u root -p < db_schema.sql
\`\`\`

### ⚙️ Step 3: Configure Environment Variables
Create a \`.env\` file in the root directory:
\`\`\`env
# GEMINI_API_KEY: Paste your Google AI Studio API key here (Optional, enables live LLM Advisory)
GEMINI_API_KEY="your_api_key_here"

# Database configs (Only if not using SQLite fallback)
MYSQL_HOST="localhost"
MYSQL_USER="root"
MYSQL_PASSWORD="your_mysql_password"
MYSQL_DATABASE="ai_portfolio_db"
\`\`\`

### 🚀 Step 4: Launch the Streamlit Terminal
\`\`\`bash
streamlit run app.py
\`\`\`
The application will boot and open automatically inside your browser at \`http://localhost:8501\`!
`
};
