import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";

const app = express();
app.use(express.json());

const PORT = 3000;

// Supported stock tickers with baseline metadata
const STOCKS_METADATA: Record<string, { name: string; sector: string; basePrice: number; beta: number; volatility: number }> = {
  AAPL: { name: "Apple Inc.", sector: "Technology", basePrice: 185.50, beta: 1.20, volatility: 0.18 },
  MSFT: { name: "Microsoft Corporation", sector: "Technology", basePrice: 420.20, beta: 1.15, volatility: 0.16 },
  GOOG: { name: "Alphabet Inc.", sector: "Technology", basePrice: 175.80, beta: 1.18, volatility: 0.19 },
  NVDA: { name: "NVIDIA Corporation", sector: "Technology", basePrice: 875.12, beta: 1.85, volatility: 0.35 },
  AMZN: { name: "Amazon.com, Inc.", sector: "Consumer Cyclical", basePrice: 180.40, beta: 1.14, volatility: 0.22 },
  TSLA: { name: "Tesla, Inc.", sector: "Consumer Cyclical", basePrice: 178.20, beta: 1.62, volatility: 0.38 },
  NFLX: { name: "Netflix, Inc.", sector: "Communication Services", basePrice: 610.50, beta: 1.28, volatility: 0.25 },
  META: { name: "Meta Platforms, Inc.", sector: "Communication Services", basePrice: 495.30, beta: 1.22, volatility: 0.24 },
  BRK_B: { name: "Berkshire Hathaway Inc.", sector: "Financial", basePrice: 405.10, beta: 0.88, volatility: 0.12 },
  JPM: { name: "JPMorgan Chase & Co.", sector: "Financial", basePrice: 195.40, beta: 1.05, volatility: 0.15 }
};

// Seed historical prices for the past 30 days
const generateHistoricalPrices = () => {
  const history: Record<string, { date: string; price: number }[]> = {};
  const today = new Date();
  
  Object.keys(STOCKS_METADATA).forEach(ticker => {
    const meta = STOCKS_METADATA[ticker];
    const tickerHistory: { date: string; price: number }[] = [];
    let currentPrice = meta.basePrice;
    
    // Generate backwards from today
    for (let i = 29; i >= 0; i--) {
      const d = new Date(today);
      d.setDate(today.getDate() - i);
      const dateStr = d.toISOString().split('T')[0];
      
      // Random walk with sector trends
      const changePercent = (Math.random() - 0.49) * 2 * (meta.volatility / Math.sqrt(252));
      currentPrice = currentPrice * (1 + changePercent);
      tickerHistory.push({ date: dateStr, price: parseFloat(currentPrice.toFixed(2)) });
    }
    history[ticker] = tickerHistory;
  });
  return history;
};

let stockHistories = generateHistoricalPrices();

// Live ticker tracker that fluctuates on request to feel entirely real-time
const getLivePrices = () => {
  const livePrices: Record<string, { price: number; change: number; changePercent: number; name: string; sector: string; beta: number; volatility: number }> = {};
  
  Object.keys(STOCKS_METADATA).forEach(ticker => {
    const meta = STOCKS_METADATA[ticker];
    const history = stockHistories[ticker];
    const yesterdayPrice = history[history.length - 2]?.price || meta.basePrice;
    
    // Slight tick fluctuation from the last historical point
    const lastHistPrice = history[history.length - 1].price;
    const tick = (Math.random() - 0.5) * 0.005; // -0.25% to +0.25% instant fluctuation
    const currentPrice = parseFloat((lastHistPrice * (1 + tick)).toFixed(2));
    
    const change = parseFloat((currentPrice - yesterdayPrice).toFixed(2));
    const changePercent = parseFloat(((change / yesterdayPrice) * 100).toFixed(2));
    
    livePrices[ticker] = {
      price: currentPrice,
      change,
      changePercent,
      name: meta.name,
      sector: meta.sector,
      beta: meta.beta,
      volatility: meta.volatility
    };
  });
  return livePrices;
};

// API: Get live prices
app.get("/api/stocks", (req, res) => {
  res.json({
    live: getLivePrices(),
    history: stockHistories
  });
});

// API: AI recommendations using server-side Gemini SDK
app.post("/api/recommendations", async (req, res) => {
  const { portfolio, riskProfile, investmentGoal } = req.body;
  
  // Format portfolio for AI review
  const portfolioText = portfolio && portfolio.length > 0 
    ? portfolio.map((item: any) => `${item.ticker}: ${item.shares} shares @ Avg Purchase Price $${item.purchasePrice}`).join(", ")
    : "No shares added yet (Empty portfolio)";

  const prompt = `
You are the AI Chief Investment Officer for the AI Portfolio Intelligence System.
Provide an institutional-grade portfolio analysis and investment recommendation report.

--- USER INTAKE CONFIGURATION ---
Active Portfolio Holdings: [ ${portfolioText} ]
Risk Tolerance Profile: ${riskProfile || "Moderate"}
Primary Financial Objective: ${investmentGoal || "Balanced Growth & Dividend Reinvestment"}

--- ANALYSIS REQUIREMENTS ---
Please deliver a highly detailed, professional analysis structured with these exact sections:
1. Executive Portfolio Health Check: Brief audit of current setup.
2. Asset Allocation & Sector Diversification Audit: Breakdown of risk/sectors.
3. Quant Risk Assessment: Explain beta, volatility, and downside risk based on the holdings (or potential additions).
4. Machine Learning Investment Recommendations:
   - Specific BUY/SELL/HOLD recommendations with price limits or triggers.
   - Recommended tactical modifications for risk mitigation.
5. Technical Out-performance Forecast: Next-quarter market themes to watch based on current macroeconomic indicators.

Format the output cleanly in readable Markdown. Keep it actionable, highly sophisticated, and free of clinical jargon.
`;

  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === "MY_GEMINI_API_KEY" || apiKey === "") {
    // Elegant fallback simulation if user hasn't configured key yet
    return res.json({
      text: `### AI Advisory Report — (Simulation Mode: API Key Pending)

⚠️ *Note: To generate actual live-reasoning reports from Gemini, please configure your \`GEMINI_API_KEY\` in the **Settings > Secrets** panel.*

#### 1. Executive Portfolio Health Check
- **Current Assessment**: Your current portfolio [**${portfolioText}**] presents a high focus on core market leaders.
- **Risk Profile Compatibility**: Currently matching a **${riskProfile || "Moderate"}** profile.
- **Recommendation**: Adding defensive counters or financial hedges is advised to offset technological volatility.

#### 2. Sector Allocation Audit
- **Technology Sector**: High-beta concentration. Excellent for momentum, but exposes the core capital during correction drawdowns.
- **Consumer Cyclical**: Balanced. Driven by inflation-resilient discretionary purchasing indices.
- **Recommendation**: Reallocate 15% of high-multiple equity into consumer defensive (e.g., BRK.B or financial leaders like JPM) to compress overall portfolio volatility.

#### 3. Quant Risk Analysis
- **Composite Beta**: Estimated at ~**1.35** (market-beating, but sensitive to interest rate fluctuations).
- **Maximum Expected Drawdown (95% VAR)**: Calculated at **14.2%** over a 30-day lookback interval.
- **Diversification Score**: **6.8 / 10** (Moderately Concentrated).

#### 4. Machine Learning Actions (Tactical BUY/SELL/HOLD)
- 🟢 **BUY (Accumulate)**: **JPM** (Target: < $190, current financial indicators show high institutional fund inflows).
- 🟢 **BUY (Growth)**: **NVDA** (Target: < $850, AI datacenter CAPEX remains highly robust).
- 🟡 **HOLD**: **AAPL** (Value consolidation phase, strong balance sheet provides a defensive floor).
- 🔴 **TRIM / SELL**: **TSLA** (Short-term margin headwind; trim 5% exposure to fund defensive buffer).

#### 5. Strategic Macro Forecast
We anticipate a shift toward value-oriented financial names and steady margin generators. Focus on building systematic cash reserves to accumulate key compounding giants during technical consolidations.`,
      isSimulated: true
    });
  }

  try {
    const ai = new GoogleGenAI({
      apiKey: apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
    });

    res.json({
      text: response.text || "No response received from Gemini.",
      isSimulated: false
    });
  } catch (error: any) {
    console.error("Gemini API Error:", error);
    res.status(500).json({ error: error.message || "Failed to communicate with AI Advisor." });
  }
});

// Serve frontend assets in production or integrate Vite in dev
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
